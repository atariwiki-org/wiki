This package contains 

- the BIBO-Assembler source code build #003
Issue with VIMIRQ key press when running a program with RUN
fixed.
To compile it you should use the XASM 3.0.1 cross-assembler by
Piotr Fusik.
The MAC OS X version is included in this package. 

- the BIBO-Assembler manual (LaTex source) - only in German, sorry.

Ghost, 03/02/2013 
