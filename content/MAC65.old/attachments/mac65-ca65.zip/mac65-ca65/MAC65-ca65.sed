#!/bin/sed -f

# Remove the trailing ASCII SUB character
s/\x1a//

# Replace @ before start of ; comment (but not i '-delimited strings) with _
: LOOP_AT
#s/^\([^;]*\)@\(.*\)$/\1_\2/
s/^\([^;']*\('[^']*'[^;']*\)*\)@\(.*\)$/\1_\3/
t LOOP_AT

# Replace . before start of ; comment (but not i '-delimited strings) with D
: LOOP_DOT
#s/^\([^;]*\)\.\(.*\)$/\1D\2/
s/^\([^;']*\('[^']*'[^;']*\)*\)\.\(.*\)$/\1D\3/
t LOOP_DOT

# Add ; at begin of lines starting with $eject
s/^\(\$eject\)/;\1/

# Add ; at begin of lines starting with $title
s/^\(\$title\)/;\1/

# Add ; at begin of lines starting with $subtitle
s/^\(\$subtitle\)/;\1/

# Change $if to .IF
s/\(\$if\)/.IF/

# Change $else to .ELSE
s/\(\$else\)/.ELSE/

# Change $endif to .ENDIF
s/\(\$endif\)/.ENDIF/

# Replace oss? with ossq
s/oss?/ossq/

# Replace ddt? with ddtq
s/ddt?/ddtq/

# Replace endl? with endlq
s/endl?/endlq/

# Replace lnum? with lnumq
s/lnum?/lnumq/

# Replace endexp? with endexpq
s/endexp?/endexpq/

# Replace #''' with #$27
s/#'''/#$27/

# Rename label "cmp" to "cmp_"
s/cmp     proc/cmp_    proc/
s/jsr     cmp/jsr     cmp_/

Rename one of two occurrences of label "DDj" to DDj_"
4487,4493 s/DDj/DDj_/

Rename one of two occurrences of label "DDtop" to DDtop_"
11309,11319 s/DDtop/DDtop_/

# Add .INCLUDE "gustafson.inc" in the first line
1 s/^/	.INCLUDE	\"gustafson.inc\"\n/

