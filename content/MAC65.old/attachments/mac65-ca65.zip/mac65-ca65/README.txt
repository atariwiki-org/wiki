Date: 2020-06-14
Contact the author: kr0tki (at) poczta.onet.pl

This package contains files necessary to compile the sources
of MAC/65 published as "Mac65.zip" in this post:
https://atariage.com/forums/topic/270944-mac65-source-code/

=== I. About the Mac65.zip archive ===

The archive contains source code for the cartridge version of MAC/65 v1.01
with DDT. It is in the format of ICD's internal cross-assembler by Mike
Gustafson. Original source for MAC/65 was written by Stephen D. Lawrow in
MAC/65 itself, but when ICD got the sources from OSS, they converted it to
Gustafson's cross-assembler. (Source:
https://atariage.com/forums/topic/270944-mac65-source-code/?do=findComment&comment=3867397)

The source package contains 9 files. 8 of them are sources of various segments:
BANKA.ASM
BANKB.ASM
BANKC.ASM
DDT.ASM
EQUATE.ASM
MAIN.ASM
MISC.ASM
TOKENS.ASM

The remaining file, MAC65.ASM, is just the contents of those 8 files joined
together.

So, to compile the sources, one needs to only use MAC65.ASM.

The original MAC/65-formatted code contained the master source file
appropriately named MASTER, that would include other source files and assemble
the full ROM image. This package does not contain a counterpart of the master
file. The sources contain definitions of labels such as "@@base" or "romf", but
they are left unused, and there are no "org" statements that should define
memory locations of code segments. So, the locations of code segments have to
be determined by comparison to other known versions of MAC/65 sources.

== II. About this package ===

Gustafson's cross-assembler is unavailable, so I have prepared necessary files
to allow compilation of MAC65.ASM with the ca65 assembler and the ld65 linker.
To use this package, you'll need the following tools:
* ca65 and ld65 ( https://cc65.github.io/ )
* sed
* make

The package's contents are:
* MAC65-ca65.sed - a sed script that converts MAC65.ASM to ca65 syntax
* gustafson.inc - an asm include file that defines missing macros from
Gustafson's cross-assembler
* MAC65.cfg - ld65 config file
* Makefile - a make script that does the building.

To compile the program:
1. Get the MAC/65 1.01 source archive (Mac65.zip)
2. Unzip this archive.
3. Copy MAC65.ASM from Mac65.zip to the directory unzipped in step 2.
4. Edit MAC65.ASM, redefining the labels:
   a) ram -> set to 0
   b) eprom -> set to 1
5. make

This will create a file named MAC65.rom. It is an Atari 16 KB ROM image in the
"OSS one-chip cartridge (M091)" format.

It turns out that the resulting image is identical to the MAC/65 1.01 cartridge
published by OSS back in 1984. It is of note however, that the sources in
Mac65.zip were apprently prepared by editing sources of some later MAC/65
version to make them identical to the 1.01 release. It is suggested by the
comments in MAC65.ASM at lines 366-367, 1889-1890, 2617, 2640, 2868, 6324-6325,
6533, 7180-7181, 11307 and 11592.
