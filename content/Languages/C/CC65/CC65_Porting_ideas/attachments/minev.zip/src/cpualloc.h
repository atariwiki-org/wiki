#ifndef CPUALLOC_H
#define CPUALLOC_H 1

void InitCPUAlloc(void);
short NewCpu(void);
void FreeCpu(const short deadcpu);

#endif
