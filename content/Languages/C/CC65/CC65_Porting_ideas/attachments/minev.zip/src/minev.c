#include <stdio.h>
#include <limits.h>

#include "consts.h"
#include "structs.h"
#include "slicer.h"
#include "soup.h"
#include "cpualloc.h"
#include "parser.h"
#include "cpuops.h"
#include "minrand.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

void InitOpcodes(void);

void  (*gOpcodes[NUM_OPCODES])(const short the_cpu, char *const name);
                                  /* Array of pointers to functions returning
                                     void. Used to decode which instruction
                                     goes with which function. */

CPU gCpus[NUM_CPUS];                 /* Array of CPU structures that are
                                        allocated to individual organisms. */

unsigned char gSoup[SOUP_SIZE];      /* The memory pool where the creatures
                                        live. */

unsigned short gSliceHead = (unsigned short)-1;
                                     /* The head of the slicer queue. */
unsigned short gFreeHead;            /* The head of the cpu freelist. */
unsigned long gInstsExecuted = 0;    /* How many instructions have been
                                        executed up to now. */

short gPenalty = DEFAULT_EXCEP_PENALTY;
                                     /* How harshly an organism is punished
                                        for CPU exceptions. */
unsigned char gNoOpZero, gNoOpOne;   /* Holds the current numeric opcodes
                                        associated with the no-ops used in
                                        jump templates. */
short  gSoupFill = 0;                /* How full the soup is at the moment. */
unsigned short gNumCells;   /* How many organisms there are. */
short  gOpsPerSlice = DEFAULT_OPS_PER_SLICE;
                                     /* The number of instructions a cell can
                                        execute per timeslice. */
unsigned short gThreshold = DEFAULT_MIN_WRITE_THRESHOLD;
                                     /* How numerous a genome must be before
                                        the system will write it to disk. */
short  gCPUFailRate = DEFAULT_CPU_FAIL_RATE;
                                     /* How often the CPU's fail. (Fails 2
                                        out of gCPUFailRate times. If zero,
                                        no failures.) */
short  gDataMutationRate = DEFAULT_TRANS_ERR_RATE;
                                     /* How often errors occur while accessing
                                        the soup. (If zero, no errors.) */

RandData gRandData;                  /* Used by the random number generator. */

FILE *gInputFile;                   /* File to read commands from. */

/* The cpu opcodes are accessed via an array of function pointers. The
   numbers in the soup that make up a creature are decoded by using them
   as subscripts into this array. This way, the number<->opcode assignment
   can be easily changed. This function sets up the default ordering. */
void InitOpcodes(void) {
  gOpcodes[0x00] = nop0;
  gOpcodes[0x01] = nop1;
  gOpcodes[0x02] = pusha;
  gOpcodes[0x03] = pushb;
  gOpcodes[0x04] = pushc;
  gOpcodes[0x05] = pushd;
  gOpcodes[0x06] = popa;
  gOpcodes[0x07] = popb;
  gOpcodes[0x08] = popc;
  gOpcodes[0x09] = popd;
  gOpcodes[0x0a] = movii;
  gOpcodes[0x0b] = inc;
  gOpcodes[0x0c] = dec;
  gOpcodes[0x0d] = zeroc;
  gOpcodes[0x0e] = lowc;
  gOpcodes[0x0f] = shl;
  gOpcodes[0x10] = ifz;
  gOpcodes[0x11] = jmp;
  gOpcodes[0x12] = jmpf;
  gOpcodes[0x13] = jmpb;
  gOpcodes[0x14] = call;
  gOpcodes[0x15] = ret;
  gOpcodes[0x16] = adr;
  gOpcodes[0x17] = adrb;
  gOpcodes[0x18] = adrf;
  gOpcodes[0x19] = mal;
  gOpcodes[0x1a] = div;
  gOpcodes[0x1b] = swap;
  gOpcodes[0x1c] = dup;
  gOpcodes[0x1d] = add;
  gOpcodes[0x1e] = sub;
  gOpcodes[0x1f] = ifl;

  gNoOpZero = 0;
  gNoOpOne = 1;
}

int main(int argc, char *argv[]) {

  gInputFile = stdin; /* We might use a script file, but we'll stick
			 with stdin for now. */

  InitRandom(1); /* Make sure the rng is set up. */
  InitCPUAlloc(); /* We have poor man's malloc for CPUs. */
  InitSoup(); /* Make sure all slots are marked unowned. */
  InitOpcodes(); /* Set up the function pointer table. */

  /* Minev can read command from a script file if one is supplied as a
     command-line argument. (In unix land, you can pipe one in, too.) */
  if (argc > 1) {
    if (argc > 2) {
      printf("usage - minev [script]\n");
#if VAX
      return; /* The VAX prints out a bogus error if you return anything. */
#else
      return(-1); /* Give an error to the system. */
#endif
    }
    else {
      /* If there's a command-line argument, assume it's a script. */
      gInputFile = fopen(argv[1], "r");
      if (NULL == gInputFile) {
        printf("Couldn't open script file %s.\n", argv[1]);
        printf("  (usage - minev [script])\n");
#if VAX
        return;
#else
        return(-1); /* Give an error to the system. */
#endif
      }
    }
  }

  Parser(); /* Enter the command loop. */

#if VAX
  return;
#else
  if (gNumCells > 0) {
    return(0);
  }
  else {
    return(-1); /* Scripts can check if things went extinct. */
  }
#endif
}
