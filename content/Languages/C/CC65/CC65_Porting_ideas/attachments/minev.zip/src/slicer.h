#ifndef SLICER_H
#define SLICER_H 1

#include "structs.h"

void Slicer (const unsigned long slices);
void AddSliceCell (const short parent, const short kid_cpu);
void DeleteSliceCell (const short deceased);

#endif
