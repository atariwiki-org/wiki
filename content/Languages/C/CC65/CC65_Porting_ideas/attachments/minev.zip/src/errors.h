#ifndef ERRORS_H
#define ERRORS_H 1

#define ER_NO_ERROR               0
#define ER_STACK_OVERFLOW         1
#define ER_STACK_UNDERFLOW        2
#define ER_BAD_ADDRESS            3
#define ER_BAD_SIZE               4
#define ER_CPUPTR_NULL            5
#define ER_ALLOC_FAIL             6
#define ER_ALLOC_CHILD_ALREADY    7
#define ER_DEAL_NOT_OWNER         8
#define ER_WRITE_NOT_OWNER        9
#define ER_NO_TEMPLATE           10
#define ER_SEARCH_NOT_FOUND      11
#define ER_INVALID_OPCODE        12
#define ER_DIV_NO_CHILD          13
#define ER_BAD_FILE              14

#endif
