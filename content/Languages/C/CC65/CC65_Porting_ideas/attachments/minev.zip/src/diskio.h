#ifndef DISKIO_H
#define DISKIO_H 1

short SeedSoup(char *const filename, short adr);
int GenCompare(const short cpu1, const short cpu2);
void WriteGenome(const short keeper, const short number);

void GlobalsSave(FILE *const fp);
void CpusSave(FILE *const fp);
void SoupSave(FILE *const fp);
void SaveState(char *filename);

void GlobalsRestore(FILE *const fp);
void CpusRestore(FILE *const fp);
void SoupRestore(FILE *const fp);
void RestoreState(char *filename);

void SaveOrganisms(void);

#endif
