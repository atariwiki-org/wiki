#include <assert.h>

#if (SPARC || SGI)
/* "meset()" is defined in "memory.h" on these systems. */
#include <memory.h>
#else
#include <string.h>
#endif

#include "consts.h"
#include "errors.h"
#include "structs.h"
#include "globals.h"
#include "mutation.h"
#include "soup.h"
#include "cpu.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/* Initializes the soup. */

void InitSoup()
{
#if ZERO_SOUP
  memset(gSoup, 0, SOUP_SIZE);
#else
  long i;

  for (i=0; i<SOUP_SIZE; i++) {
    /* Leave random garbage in the soup but, at least, unallocate it. */
    gSoup[i] &= SOUP_STRIP_MASK;
  }
#endif
}

/* Write data to the soup. The 'mutate' flag specifies whether there is to
   be a chance of mutating the data before storage. (Only the 'OS' gets
   to avoid mutation.) */
void WriteSoup(const short adr, const unsigned char val, const char mutate)
{
  /* Note that by doing this bit-twiddling we preserve the ownership
     bit of the soup we're writing to. */
  gSoup[adr] &= SOUP_ALLOCATE_MASK; /* remove any data in the soup. */

  if (mutate) {
    gSoup[adr] |= (val ^ DataMutate());
  }
  else {
    gSoup[adr] |= val;
  }
}

/* Allocate space in the soup for a call. Try to get a block of size 'size'
   as close as possible to 'pref', returning (if successful) to *retadr.
   Returns a code indicating status.
   I'm not really happy with this code - it's too large and complicated.
   Suggestions welcome. */

short AllocSoup(const short pref, const short size, short *const retadr)
{
  int count, mark, forw = -1, back= -1;
  long i, limit, start;

  /* These two check to see if the request is a rational one. */
  if (pref < 0) {
    return(ER_BAD_ADDRESS);
  }
  if (pref >= SOUP_SIZE) {
    return(ER_BAD_ADDRESS);
  }

  if (size > MAX_ALLOC_SIZE) {
    return(ER_BAD_SIZE);
  }

  if (size < MIN_ALLOC_SIZE) {
    return(ER_BAD_SIZE);
  }

  /* Figure out how far forward to search - don't go off the end of
     the soup! */
  limit = (long)((pref+SOUP_ALLOC_SEARCH) > SOUP_SIZE ? SOUP_SIZE :
                      (pref+SOUP_ALLOC_SEARCH));

  /* Start at 'pref', go to 'limit'. Keep track of the size of the
     current unallocated block; stop when you find one of size 'size'. */
  for (i=pref, count = 0; i<limit && count < size; i++) {
    if (gSoup[i] & SOUP_ALLOCATE_MASK) {
      count = 0; /* this block was too small */
    }
    else {
      count++;
    }
  }

  /* Did we find anything? */
  if (count == size) {
    forw = i - count;
  }

  /* Figure out how far back to search. */
  limit = (pref-SOUP_ALLOC_SEARCH) < 0 ? 0 : (pref-SOUP_ALLOC_SEARCH);
  /* Figure out where to start from. */
  start = pref+size-2 > SOUP_SIZE-1 ? SOUP_SIZE-1 : pref+size-2;

  /* Note that we start this one at 'pref+size-2'. We've already searched
     at 'pref', this checks below pref. */
  for (i=start, count=0; i>limit && count<size; i--) {
    if (gSoup[i] & SOUP_ALLOCATE_MASK) {
      count = 0; /* this block was too small */
    }
    else {
      count++;
    }
  }

  /* Did we find anything? */
  if (count == size) {
    back = i+1;
  }

  /* Now, if we've found two blocks, we return the closest one. */
  if (back >= 0) {
    if (forw >=0) {
      /* Found two, choose closest. */
      mark = (pref-back) < (forw-pref) ? back : forw;
    }
    else {
      /* Only found one looking back. */
      mark = back;
    }
  }
  else {
    /* Did we find one going forward? */
    if (forw >= 0) {
      /* Only found a forward one. */
      mark = forw;
    }
    else {
      /* Didn't find anything. Ah, well. */
      return (ER_ALLOC_FAIL);
    }
  }

  /* Let the cell know what it's won! */
  *retadr = mark;

  /* Mark the soup as allocated by someone. */
  for (i=0; i<size; i++) {
    assert((mark + i < SOUP_SIZE) && (mark+i >=0));
    assert(!(gSoup[mark + i] & SOUP_ALLOCATE_MASK));
    gSoup[mark + i] |= SOUP_ALLOCATE_MASK;
  }

  /* Keep the OS appraised of the soup contents. */
  gSoupFill += size;

  /* Yay! We made it! */
  return(ER_NO_ERROR);
}

/* Marks soup as unallocated by stripping off the high bits. (The values
   passed to this function come from the "OS", which hopefully knows
   what it's doing. Hence the only error checking is done via an assert.) */
void DeallocSoup(const short adr, const short size)
{
  unsigned short i;

  for (i=adr; i<adr+size; i++) {
    assert(gSoup[i] & SOUP_ALLOCATE_MASK); /* See if it's really owned. */
    gSoup[i] &= SOUP_STRIP_MASK;
  }
  /* Better keep track for the statisticians. */
  gSoupFill -= size;
}

/*****
*
* Search forward for template.
*
*****/

short ForwSoupSearch(const short start, short *const retadr) {
  long i, j, limit;
  unsigned char tsize, template[MAX_TEMPLATE_SIZE];

  /* Find the template, if any. */
  for (i=start+1, tsize=0; i < SOUP_SIZE &&
       tsize < MAX_TEMPLATE_SIZE; i++, tsize++) {
    if (IsNoOp(SafeReadSoup(i))) {
      /* Note: we invert search template here with OtherNoOp. */
      template[tsize] = OtherNoOp(SafeReadSoup(i));
    }
    else {
      break; /* not a no-op, so not part of a template */
    }
  }

  /* Make sure we found a template to search on. */
  if (0 == tsize) {
    return(ER_NO_TEMPLATE);
  }

  /* Figure out how far ahead we're searching. */
  limit = (SOUP_SIZE - SOUP_TEMPLATE_SEARCH < start) ? SOUP_SIZE :
    (start + SOUP_TEMPLATE_SEARCH);

  /* Here's the actual search. It just scans the soup looking for
     anything that matches the (inverted) template it has. */
  for (i=start; i<limit-tsize; i++) {
    for (j=0; j<tsize; j++) {
      if (SafeReadSoup(i+j) != template[j]) {
        break;
      }
    }
    if (j == tsize) {
      /* We found one! Note that a small template can match a subset of
         a larger template... */
      *retadr = i+tsize;
      return(ER_NO_ERROR);
    }
  }

  /* We didn't find anything. */
  return(ER_SEARCH_NOT_FOUND);
}

/* Search backward in the soup for a template. */
short BackSoupSearch(const short start, short *const retadr) {
  long i,j;
  long limit;
  unsigned char tsize, template[MAX_TEMPLATE_SIZE];

  /* Find the template, if any... */
  for (i=start+1, tsize=0; i < SOUP_SIZE &&
       tsize < MAX_TEMPLATE_SIZE; i++, tsize++) {
    if (IsNoOp(SafeReadSoup(i))) {
      /* Note: we invert search template here with OtherNoOp. */
      template[tsize] = OtherNoOp(SafeReadSoup(i));
    }
    else {
      break; /* not a no-op, so not part of a template */
    }
  }

  /* Did we find a template? */
  if (0 == tsize) {
    return(ER_NO_TEMPLATE);
  }

  /* Figure out how far back to search - don't need a segmentation
     violation from going below the bottom of the soup! */
  limit = (start < SOUP_TEMPLATE_SEARCH) ? 0 : (start - SOUP_TEMPLATE_SEARCH);

  /* Actually do the search. */
  for (i=start; i>=limit; i--) {
    for (j=0; j<tsize; j++) {
      if (SafeReadSoup(i+j) != template[j]) {
        break;
      }
    }
    if (j == tsize) {
      /* Found something! */
      *retadr = i+tsize;
      return(ER_NO_ERROR);
    }
  }

  /* We didn't find anything. */
  return(ER_SEARCH_NOT_FOUND);
}
