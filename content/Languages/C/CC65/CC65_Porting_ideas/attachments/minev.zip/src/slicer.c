#include <assert.h>

#include "consts.h"
#include "structs.h"
#include "globals.h"

#include "cpu.h"
#include "slicer.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/* Doles out timeslices to cells. DoSlice() takes care of advancing
   gSliceHead. */
void Slicer (const unsigned long slices) {
  unsigned long i;

  for (i=0; i<slices; i++) {
    if (gSliceHead < 0) { /* for paranoia - user could say "go" when */
      break;              /* no organisms are loaded. */
    }
    else {
      DoSlice(); /* Let's go. */
    }
  }
}

/* Add a cell to the slicer queue. Handles the special case of inserting
   onto an empty list. (Note: in that case, the value of "parent" is
   ignored.) */
void AddSliceCell (const short parent, const short kid)
{

  if (-1 == parent) { /* We're adding a new seed to a soup. */
    if (-1 != gSliceHead) { /* There's already at least one. */
      /* Add it to the end of the queue. It only gets a turn after
         everyone else does. */
      gCpus[kid].sprev = gCpus[gSliceHead].sprev;
      gCpus[gSliceHead].sprev = kid;
      gCpus[gCpus[kid].sprev].snext = kid;
      gCpus[kid].snext = gSliceHead;
    }
    else { /* List is empty. We're initializing the soup. */
      gSliceHead = kid;
      gCpus[kid].snext = kid;
      gCpus[kid].sprev = kid;
    }
  }
  else { /* It's someone's kid. */
    assert(-1 != gSliceHead); /* make sure the list isn't empty */
    /* Insert the kid into the queue just before the parent. This means
       everyone else will get a slice before the kid does - i.e. the kid
       starts at the end of the line. */
    gCpus[kid].sprev = gCpus[parent].sprev;
    gCpus[parent].sprev = kid;
    gCpus[gCpus[kid].sprev].snext = kid;
    gCpus[kid].snext = parent;
  }
}

/* Remove an element from the slicer queue. Handles the special case of
   deleting the last element. */
void DeleteSliceCell (const short deceased)
{
  if (gCpus[deceased].snext == deceased) { /* this is the last element */
    assert(gSliceHead == deceased); /* ...so it should be head. */
    gSliceHead = -1; /* No cells to run. */
  }
  else { /* The list isn't empty yet */
    /* Remove the element from the queue. */
    if (gSliceHead == deceased) {
      gSliceHead = gCpus[deceased].snext;
    }
    gCpus[gCpus[deceased].sprev].snext = gCpus[deceased].snext;
    gCpus[gCpus[deceased].snext].sprev = gCpus[deceased].sprev;
    gCpus[deceased].snext = -1;
    gCpus[deceased].sprev = -1;
  }
}
