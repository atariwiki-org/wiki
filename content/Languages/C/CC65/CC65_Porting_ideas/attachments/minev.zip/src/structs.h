#ifndef STRUCTS_H
#define STRUCTS_H 1

#include "consts.h"

/* Note: The 'sp' at the the end *is* at the end for a reason: on some
   systems, it might save one byte per struct if they don't have to be
   padded. Mostly it won't, and you can just treat these CPU structs as
   38 bytes long. See the README file and consts.h for why that's at all
   important. */
typedef struct cpu {
  short ax,bx,cx,dx; /* registers */

  short ip; /* instruction pointer */

  /* "pointers" to list elements (slicelist) */
  short snext, sprev;

  /* How long the organism has to live. */
  short span;

  short home, child; /* addressed of cell and its kid */
  short hsize, csize; /* size of home and kid */

  short fl; /* indicates cpu exceptions */
            /* (also used as a pointer for cpu allocator - */
            /* 'fl' could stand for 'flag' or 'freelist') */

  short st[STACK_SIZE]; /* stack */
  unsigned char sp; /* stack pointer */
} CPU;

/* This holds the internal data of the random number generator. */

typedef struct randdata {
  long ShufTable[NUM_SHUFFLES]; /* Used to shuffle the output of the
                                    random number generator to improve
                                    the statistical properties. */
  long ShufAux;                 /* Auxiliary variable used in the
                                    shuffling. */
  long RandKey;                 /* State of the linear congruential
                                    generator. */
} RandData;


#endif
