#ifndef RANDOM_H
#define RANDOM_H 1

long MinevRandom(void);
void InitRandom(long seed);
short RangedRandom(const short max);

#endif

