$ ! -----------------------------------------------------------------------
$ ! Note that, if you want to use minev's script-reading ability on the
$ ! VAX, you have to install minev as a 'DCL foreign command' every time
$ ! you log on. You might want to put that line in your login.com.
$ !
$ ! Edit this to point to the directory you're installing minev to.
$ ! A good choice might be your current directory.
$ ! (I strongly doubt the default will work for you. :-> )
$ !
$ executable_path="disk:[path.to.minev]"
$ !
$ ! NO NEED TO EDIT BELOW THIS LINE. BUT IF YOU KNOW MORE THAN I DO
$ ! ABOUT VAXEN (WHICH IS QUITE LIKELY) IT MIGHT BE A GOOD IDEA.
$ ! -----------------------------------------------------------------------
$ !
$ ! For use with the VAX C compiler. (If you have better flags, use 'em.)
$ !
$ compiler_flags="/inc=[] /define=VAX /define=NDEBUG /optimize"
$ !
$ ! Compile the various files.
$ !
$ WRITE sys$output "Installing to ", executable_path
!
$ WRITE sys$output "Compiling files..."
$ WRITE sys$output "Compiling diskio.c..."
$ cc diskio.c 'compiler_flags'
$ WRITE sys$output "Compiling cpuops.c..."
$ cc cpuops.c 'compiler_flags'
$ WRITE sys$output "Compiling parser.c..."
$ cc parser.c 'compiler_flags'
$ WRITE sys$output "Compiling cpu.c..."
$ cc cpu.c 'compiler_flags'
$ WRITE sys$output "Compiling soup.c..."
$ cc soup.c 'compiler_flags'
$ WRITE sys$output "Compiling minev.c..."
$ cc minev.c 'compiler_flags'
$ WRITE sys$output "Compiling slicer.c..."
$ cc slicer.c 'compiler_flags'
$ WRITE sys$output "Compiling cpualloc.c..."
$ cc cpualloc.c 'compiler_flags'
$ WRITE sys$output "Compiling minrand.c..."
$ cc minrand.c 'compiler_flags'
$ WRITE sys$output "Compiling mutation.c..."
$ cc mutation.c 'compiler_flags'
$ WRITE sys$output "Compiling stack.c..."
$ cc stack.c 'compiler_flags'
$ !
$ ! *Actually link the resultant object files.
$ !
$ WRITE sys$output "Linking minev.exe..."
$ link /exe=minev.exe diskio,cpuops,parser,cpu,soup,minev,slicer,cpualloc,minrand,mutation,stack
$ !
$ ! *Install as a 'DCL foreign command' so it can receive command-line args
$ !
$ ! Comment out these lines if you don't want to install minev as a
$ ! foreign command
$ WRITE sys$output "Setting 'minev' command to point to"
$ WRITE sys$output executable_path, "minev.exe"
$ minev :== $'executable_path'minev.exe
$ !
$ ! All done.
$ !
$ WRITE sys$output "Make finished."
$ EXIT
