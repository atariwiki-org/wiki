#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>

#include "consts.h"
#include "errors.h"
#include "structs.h"
#include "globals.h"

#include "parser.h"
#include "slicer.h"
#include "minrand.h"
#include "mutation.h"
#include "diskio.h"
#include "soup.h"
#include "cpu.h"
#include "cpualloc.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

FILE *scriptFile; /* The currently open input file. */

/* Displays the help text. */
void PrintHelp(void)
{
  printf("Quit to quit. Help or '?' for help.\n");
  printf("File [name] to read commands from file [name].\n");
  printf("Init [name] ([adr]) to initialize soup with a seed file.\n");
  printf("Go [num] to go for [num] timeslices.\n");
  printf("Read [adr] ([length]) shows contents of the soup.\n");
  printf("Cpu [adr] shows the cpu at [adr], if any.\n");
  printf("Var [name] ([val]) shows or sets the value of variables.\n");
  printf("  Fail : CPU failure rate.\n");
  printf("  Trans : Transcription error rate.\n");
  printf("  Ops : CPU operations per timeslice.\n");
  printf("  Penalty : CPU exception penalty.\n");
  printf("  Insts: Total instructions executed.\n");
  printf("  Num: Number of orgs to output a genome.\n");
  printf("  All : Print all of the above. ([val] ignored)\n");
  printf("Seed [val] seeds the random number generator.\n");
  printf("Write [name] writes state out to file [name](.st).\n");
  printf("Load [name] loads state from file [name](.st).\n");
  printf("Diddle renumbers the opcodes randomly.\n");
  printf("Orgs saves all cells more numerous than 'Num' (See 'Var').\n");
  printf("A line beginning with # is ignored (for commenting scripts).\n");
  printf("(All commands can be abbreviated with their first letter.)\n");
  printf("  and are case-insensitive (QUIT = Quit = quit = q).)\n");
}

/* Displays the error message associated with an error status */
void PrintError(const unsigned short error) {
  switch(error) {
  case ER_NO_ERROR: printf("ER_NO_ERROR\n"); break;
  case ER_STACK_OVERFLOW: printf("ER_STACK_OVERFLOW\n"); break;
  case ER_STACK_UNDERFLOW: printf("ER_STACK_UNDERFLOW\n"); break;
  case ER_BAD_ADDRESS: printf("ER_BAD_ADDRESS\n"); break;
  case ER_BAD_SIZE: printf("ER_BAD_SIZE\n"); break;
  case ER_CPUPTR_NULL: printf("ER_CPUPTR_NULL\n"); break;
  case ER_ALLOC_FAIL: printf("ER_ALLOC_FAIL\n"); break;
  case ER_ALLOC_CHILD_ALREADY: printf("ER_ALLOC_CHILD_ALREADY\n"); break;
  case ER_DEAL_NOT_OWNER: printf("ER_DEAL_NOT_OWNER\n"); break;
  case ER_WRITE_NOT_OWNER: printf("ER_WRITE_NOT_OWNER\n"); break;
  case ER_NO_TEMPLATE: printf("ER_NO_TEMPLATE\n"); break;
  case ER_SEARCH_NOT_FOUND: printf("ER_SEARCH_NOT_FOUND\n"); break;
  case ER_INVALID_OPCODE: printf("ER_INVALID_OPCODE\n"); break;
  case ER_DIV_NO_CHILD: printf("ER_DIV_NO_CHILD\n"); break;
  case ER_BAD_FILE: printf("ER_BAD_FILE\n"); break;
  default: printf("Erroneous error.\n"); break;
  }
}

/* Find the CPU (if any) that owns a given soup adddress. */
short FindSoupOwner(const short adr) {
  short temp;

  if (gSoup[adr] & SOUP_ALLOCATE_MASK) { /* Does anyone own that address? */
    assert(gSliceHead != 0); /* Are there any cpus? */
    temp = gSliceHead;
    do {
      if ((gCpus[temp].home <= adr &&
           adr < gCpus[temp].home + gCpus[temp].hsize) ||
          (gCpus[temp].child <= adr &&
           adr < gCpus[temp].child + gCpus[temp].csize)) {
        return(temp);
      }
      temp = gCpus[temp].snext; /* advance temp */ 
    } while (temp != gSliceHead);
  }
  return(0);
}

/* Display the info about a cpu at a given address. */
void PrintCpu(const short adr)
{
  short cpu;

  /* Make sure input is reasonable. */
  if (adr < 0) {
    printf("Invalid address %d.\n", adr);
    return;
  }

  cpu = FindSoupOwner(adr);
  if (cpu != 0) {
    printf("\nAt address %d:\n", adr);
    printf("ax: %d bx: %d cx: %d dx: %d\n",
           gCpus[cpu].ax, gCpus[cpu].bx, gCpus[cpu].cx, gCpus[cpu].dx);
    if (STACK_EMPTY == gCpus[cpu].sp) {
      printf("stack empty\n");
    }      
    else {
      printf("sp: %d, st[0]: %d\n", gCpus[cpu].sp, gCpus[cpu].st[0]);
    }
    printf("ip: %d\n", gCpus[cpu].ip);
    printf("lifespan: %d\n", gCpus[cpu].span);
    printf("home: %d, size: %d, child: %d, size: %d\n",
           gCpus[cpu].home, gCpus[cpu].hsize,
           gCpus[cpu].child, gCpus[cpu].csize);
    printf("flag = ");
    PrintError(gCpus[cpu].fl);
    printf("\n");
  }
  else { /* We're in business. */
    printf("No CPU owns Soup[%d].\n", adr);
  }
}

/* Show a spot in the soup. */
void ShowSoup(const short adr, const short length)
{
  short i;
  char name[10]; /* Small buffer, but opcodes have small names. */
  unsigned char opcode;

  /* Make sure the values are reasonable. */
  if (adr < 0 || length < 0 || adr + length > SOUP_SIZE) {
    printf("Can't show %d %d.\n", adr, length);
    return;
  }

  for (i=adr; i < adr+length; i++) {
    opcode = SafeReadSoup(i);
    (*gOpcodes[opcode])(0, name);
    printf("Soup[%d] - opcode: %s, cpu: %d\n", i, name, FindSoupOwner(i));
  }
}

/* Used while parsing commands, this takes a char * and increments it
   past any leading white space. Note that does not count a trailing
   '0' as white space and will leave it present. */
char *EatWhiteSpace(char *inbuf)
{
  while (*inbuf == ' ' || *inbuf == '\t' || *inbuf == '\n') {
    inbuf++;
  }
  return(inbuf);
}

/* Get the command name and any optional arguments. Should be
   relatively bulletproof. Note: returns the number of lexical
   elements found, including the command, if any. */
int ParseCommand(char *inbuf, char *command, char *arg1, char *arg2)
{
  int i, nargs = 0;

  /* Make sure that the strings are set to null and thus cannot be used
     for evil. */
  command[0] = 0;
  arg1[0] = 0;
  arg2[0] = 0;

  inbuf = EatWhiteSpace(inbuf);

  /* Get the command itself. */
  if (*inbuf != 0) { /* It's not a blank line */
    i = 0;
    while (*inbuf != 0 && *inbuf != ' ' && *inbuf != '\t' && *inbuf != '\n') {
      command[i++] = *(inbuf++);
    }
    command[i] = 0; /* Null terminate the command. */
    nargs++;
  }

  inbuf = EatWhiteSpace(inbuf);

  /* Get the first argment, if present. */
  if (*inbuf != 0) { /* It's not a blank line */
    i = 0;
    while (*inbuf != 0 && *inbuf != ' ' && *inbuf != '\t' && *inbuf != '\n') {
      arg1[i++] = *(inbuf++);
    }
    arg1[i] = 0; /* Null terminate the argument. */
    nargs++;
  }

  inbuf = EatWhiteSpace(inbuf);

  /* Get the second argment, if present. */
  if (*inbuf != 0) { /* It's not a blank line */
    i = 0;
    while (*inbuf != 0 && *inbuf != ' ' && *inbuf != '\t' && *inbuf != '\n') {
      arg2[i++] = *(inbuf++);
    }
    arg2[i] = 0; /* Null terminate the argument. */
    nargs++;
  }

  return(nargs);
}

/* Acts on the commands the user gives. Calls the appropriate functions
   to perform the user command. */
int DispatchCommand(const int nargs, char *command, char *arg1, char *arg2)
{
  unsigned long intarg = 0;

  command[0] = tolower(command[0]);

  switch(command[0]) {
  case 'q': /* User quits. */
    return(1);
    break; /* never reached, included for paranoia. */
  case 'f':
    if (nargs != 1) {
      printf("Wrong number of arguments.\n");
    }
    else {
      scriptFile = fopen(arg1, "r");
      if (NULL == scriptFile) {
	printf("Problem opening script file %s.\n", arg1);
      }
      else {
	if (gInputFile != stdin) {
	  fclose(gInputFile);
	}
	gInputFile = scriptFile;
      }
    }
    break;
  case '?':
  case 'h': /* Get help. */
    PrintHelp();
    break;
  case 'i':
    if (nargs == 1) {
      if (*arg1) {
        intarg = SeedSoup(arg1, (short)-1);
      }
    }
    else if (nargs == 2) {
      if (*arg1 && *arg2) { 
        intarg = SeedSoup(arg1, (short)atoi(arg2));
      }
    }
    else {
      printf("Invalid number of arguments, %d.\n", nargs);
      intarg = 0;
    }
    if (intarg) {
      printf("Problem seeding soup with %s\n", arg1);
    }
    break;
  case 'g':
    if (*arg1) { /* Make sure arg isn't null. */
      intarg = (unsigned long) atol(arg1);
      Slicer(intarg);
    }
    else {
      printf("Must supply go count.\n");
    }
    break;
  case 'r':
    if (nargs == 1) {
      if (*arg1) {
        intarg = atol(arg1);
        if (intarg < SOUP_SIZE) {
          ShowSoup((short)intarg, (short)20);
        }
        else {
          printf("Invalid address.\n");
        }
      }
    }
    else if (nargs == 2) {
      if (*arg1 && *arg2) {
        intarg = atol(arg1);
        if (intarg < SOUP_SIZE) {
          ShowSoup((short)intarg, (short)atoi(arg2));
        }
        else {
          printf("Invalid address.\n");
        }
      }
    }
    break;
  case 'c':
    if (*arg1) {
      intarg = (short) atol(arg1);
      if (intarg < SOUP_SIZE) {
        PrintCpu((short)intarg);
      }
      else {
        printf("Invalid address.\n");
      }
    }
    else {
      printf("Must supply address of cpu.\n");
    }
    break;
  case 'v': /* Display or set a variable's value. */
    if (nargs == 2) {
      /* Set a variable's value. */
      if (*arg1 && *arg2) {
	arg1[0] = tolower(arg1[0]);
	if (arg1[0] != 'a') {
	  intarg = atoi(arg2);
	  switch(arg1[0]) {
	  case 'f':
	    gCPUFailRate = intarg;
            if (gCPUFailRate < 0) gCPUFailRate = 0;
	    break;
	  case 't':
	    gDataMutationRate = intarg;
            if (gDataMutationRate < 0) gDataMutationRate = 0;
	    break;
	  case 'o':
	    gOpsPerSlice = intarg;
            if (gOpsPerSlice < 0) gOpsPerSlice = 0;
	    break;
	  case 'p':
	    gPenalty = intarg;
            if (gPenalty < 0) gPenalty = 0;
	    break;
	  case 'n':
	    gThreshold = intarg;
	    break;
	  case 'i':
	    gInstsExecuted = (unsigned long) atol(arg2);
	    break;
	  default:
	    printf("Unknown variable.\n");
	    break;
	  }
	}
      }
    }
    if (nargs == 1 || nargs == 2) {
      arg1[0] = tolower(arg1[0]);
      switch(arg1[0]) {
      case 'a':
      case 'f':
	printf("CPU failure rate: %d\n", gCPUFailRate);
	if (arg1[0] != 'a') {
	  break;
	}
      case 't':
	printf("Transcription error rate: %d\n", gDataMutationRate);
	if (arg1[0] != 'a') {
          break;
        }
      case 'o':
	printf("CPU operations per timeslice: %d\n", gOpsPerSlice);
	if (arg1[0] != 'a') {
	  break;
	}
      case 'p':
	printf("CPU exception penalty: %d\n", gPenalty);
	if (arg1[0] != 'a') {
	  break;
	}
      case 'n':
	printf("Organism output threshold: %d\n", gThreshold);
	if (arg1[0] != 'a') {
	  break;
	}
      case 'i':
	printf("Instructions executed: %lu\n", gInstsExecuted);
        break;
      default:
	printf("Unknown variable.\n");
	break;
      }
    }
    else {
      printf("Wrong number of arguments.\n");
    }
    break;
  case 's':
    if (*arg1) {
      InitRandom(atol(arg1));
      printf("Used random seed %ld.\n", atol(arg1));
    }
    else {
      printf("Must supply a seed.\n");
    }
    break;
  case 'w': /* Write out data to disk. */
    SaveState(arg1); /* Doesn't barf on bad data. */
    break;
  case 'l': /* Read data from disk. */
    if (*arg1) {
      RestoreState(arg1);     
    }
    else {
      printf("Must supply a filename.\n");
    }
    break;
  case 'd':
    ReorderOps();
    break;
  case 'o': /* Write out organisms to disk. */
    SaveOrganisms();
    break;
  case '#':
    break; /* Comment character. */
  default:
    printf("I don't understand: %s\n", command);
    break;
  } /* switch */
  return(0);
}

/* Actually get the user commands and act upon them. */
void Parser(void)
{
  int done = 0, nargs;
  char input[100], command[100], arg1[100], arg2[100]; /* Buffers for input. */

  do {
    printf("Insts: %lu, Soup: %d, Orgs: %d\n>>", gInstsExecuted,
           gSoupFill, gNumCells);
    if (fgets(input, 100, gInputFile) == NULL) { /* get user command */
      /* If there was a problem getting input... */
      if (gInputFile == stdin) {
	done = 1; /* Abort if problem getting input from stdin - we're
		     in trouble if that's the case. */
      }
      else {
	gInputFile = stdin; /* Well, we can't get input from wherever
			       we're reading from, so let's try stdin. */
      }
    }
    else {
      /* "nargs" returns the number of lexical elements found. */
      nargs = ParseCommand(input, command, arg1, arg2);
      if (nargs--) { /* note the postdecrement */
	done = DispatchCommand(nargs, command, arg1, arg2);
      }
    }
  } while (!done);
  printf("\n");
}
