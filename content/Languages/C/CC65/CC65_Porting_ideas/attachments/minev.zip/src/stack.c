#include <assert.h>

#include "consts.h"
#include "errors.h"
#include "structs.h"
#include "globals.h"
#include "cpu.h"
#include "stack.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/* Simple stack for minev Cpus. */

/* Pushes 'pushee' onto 'the_cpu's stack. */

short push(const short the_cpu, const short pushee) {
  if (gCpus[the_cpu].sp == STACK_EMPTY) {
    gCpus[the_cpu].sp = 0;
    gCpus[the_cpu].st[gCpus[the_cpu].sp] = pushee;
    return(ER_NO_ERROR);
  }
  else if (gCpus[the_cpu].sp < STACK_SIZE-1) { /* there's room on the stack */
    gCpus[the_cpu].st[++(gCpus[the_cpu].sp)] = pushee;
    return(ER_NO_ERROR);
  }
  else {
    return(ER_STACK_OVERFLOW); /* stack overflow */
  }
}

/* Pops the top of 'the_cpu's stack into *pushee. */

short pop(const short the_cpu, short *const popee) {
  if (gCpus[the_cpu].sp != STACK_EMPTY) {
    if (gCpus[the_cpu].sp == 0) { /* there's one thing left to pop */
      *popee = gCpus[the_cpu].st[(gCpus[the_cpu].sp)];
      gCpus[the_cpu].sp = STACK_EMPTY;
    }
    else {
      assert(gCpus[the_cpu].sp < STACK_SIZE);
      *popee = gCpus[the_cpu].st[(gCpus[the_cpu].sp--)];
    }
    return(ER_NO_ERROR);
  }
  return(ER_STACK_UNDERFLOW);
}
