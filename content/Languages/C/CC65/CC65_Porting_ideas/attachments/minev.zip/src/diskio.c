#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#if (SPARC || SGI)
#include <memory.h> /* memset(), etc. are here for no good reason. */
#else
#include <string.h>
#endif

#include "consts.h"
#include "errors.h"
#include "structs.h"
#include "globals.h"
#include "soup.h"
#include "cpu.h"
#include "cpualloc.h"
#include "slicer.h"
#include "diskio.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

const char readErrorMsg[] = "Error reading from file.\n";
const char writeErrorMsg[] = "Error writing to file.\n";

/****************************************************************
*
*  These functions handle, as you can probably guess, reading and
* writing files. "State" files are binary files that store the
* entire state of the system so it can be restored later on.
* "Seed" files contain ASCII organisms that start with zero or
* more comments, then an organism length, a default address to
* start it at, and then the names of opcodes.
*
*****************************************************************/

int GetLine(char *const buffer, const int length, FILE *const fp);

int GetLine(char *const buffer, const int length, FILE *const fp)
{
  if (NULL == fgets(buffer, length, fp)) {
    return(1);
  }
  else {
    return(0);
  }
}

/* Initialize the soup with an organism from the file named in "filename". 
   If adr > 0, override the default address in the seedfile. */
short SeedSoup(char *const filename, short adr) {
  char opname[MAX_OPCODE_NAME_SIZE], buffer[80-MAX_OPCODE_NAME_SIZE], data[80];
  short newborn, actual, op_data = -1, size;
  long i, j;

  FILE *fp;

  fp = fopen(filename, "r");
  if (fp == NULL) {
    printf("Problem opening seed file %s\n", filename);
    return (ER_BAD_FILE);
  }
  else { /* We opened the file. */
    
    /* Ignore leading comments. */
    i = 0;
    while ((0== i) && (!GetLine(data, 80, fp))) {
      if (';' != data[0]) {
        i = 1;
      }
    }
    size = (short)atoi(data);

    /* Get the default address. */
    if (fgets(data, 80, fp) == NULL) {
      printf("Problem reading address.\n");
      fclose(fp);
      return(ER_BAD_ADDRESS);
    }
    else {
      if (adr < 0) { /* User didn't specify an address - use file. */
        adr = (short)atoi(data);
      }
      if (adr < 0) {
        printf("Address out of range.\n");
	fclose(fp);
        return(ER_BAD_ADDRESS);
      }
    }

    /* Assign the organism a CPU. */
    newborn = NewCpu();
    if (newborn < 0) {
      printf("Problem allocating CPU.\n");
      fclose(fp);
      return(ER_CPUPTR_NULL);
    }
    gNumCells++;

    if (AllocSoup(adr, size, &actual)) {
      printf("Problem allocating soup.\n");
      FreeCpu(newborn); /* don't need this no more. */
      gNumCells--;
      fclose(fp);
      return(ER_ALLOC_FAIL);
    }
    else { /* Success! Let's load the soup! */
      for (i=0; i < size; i++) {
        if (fgets(data, 80, fp) == NULL) {
          printf("Problem reading opcode %d.\n", (short) i);
	  fclose(fp);
          return(ER_INVALID_OPCODE);
        }
        else {
          if (EOF == sscanf(data, "%s %s", opname, buffer)) {
            printf("Error parsing %s\n", data);
            abort();
          }

          strcpy(data, opname);

          /* Search the opcode list for this opcode. */
          for (j=0; j < NUM_OPCODES; j++) {
	    /* If their second argument is non-NULL, opcodes return
	       their name in that buffer and exit. */
            (*gOpcodes[j])(0, opname); /* Get the name of the opcode */
            if (!strcmp(data, opname)) { /* input matches an opcode */
              op_data = (short)j;
              break;
            }
          } /* end for */
          if (j == NUM_OPCODES) { /* We went through them all. */
            printf("Unknown opcode, %s\n", data);
	    fclose(fp);
            return(ER_INVALID_OPCODE);
          }
          WriteSoup((short)(actual+i), (unsigned char)op_data, NO_MUTATE);
        }
      } /* for */
    } /* load soup */
    fclose(fp);
  } /* opened file */

  /* Introduce the rest of the system to this little sucker. */
  InitCpu(newborn, size, actual);
  AddSliceCell(-1, newborn); /* It has no parent, so use -1. */
  printf("Seeded soup at address: %d\n", actual);
  return(ER_NO_ERROR);
}

/* Save or restore CPU array. */
void CpusSave(FILE *const fp)
{
  size_t output;
  output = fwrite(&(gCpus[0]), sizeof(CPU), NUM_CPUS, fp);
  if (output < NUM_CPUS) {
    printf(writeErrorMsg);
    abort();
  }
}

void CpusRestore(FILE *const fp)
{
  size_t input;

  input = fread(&(gCpus[0]), sizeof(CPU), NUM_CPUS, fp);
  if (input < NUM_CPUS) {
    printf(readErrorMsg);
    abort();
  }
}

/* Save or restore soup array. */
void SoupSave(FILE *const fp)
{
  size_t output;
  output = fwrite(&(gSoup[0]), sizeof(unsigned char), SOUP_SIZE, fp);
  if (output < SOUP_SIZE) {
    printf(writeErrorMsg);
    abort();
  }
}

void SoupRestore(FILE *const fp)
{
  size_t input;

  input = fread(&(gSoup[0]), sizeof(unsigned char), SOUP_SIZE, fp);
  if (input < SOUP_SIZE) {
    printf(readErrorMsg);
    abort();
  }
}

/* Save or restor all global variables to a state file. */
void GlobalsSave(FILE *const fp)
{
  int i;
  char opname[MAX_OPCODE_NAME_SIZE];
  fwrite(&gRandData, sizeof(RandData), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gSliceHead, sizeof(gSliceHead), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gFreeHead, sizeof(gFreeHead), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gInstsExecuted, sizeof(gInstsExecuted), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gPenalty, sizeof(gPenalty), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gNoOpZero, sizeof(gNoOpZero), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gNoOpOne, sizeof(gNoOpOne), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gSoupFill, sizeof(gSoupFill), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gNumCells, sizeof(gNumCells), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gOpsPerSlice, sizeof(gOpsPerSlice), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gThreshold, sizeof(gThreshold), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gCPUFailRate, sizeof(gCPUFailRate), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  fwrite(&gDataMutationRate, sizeof(gDataMutationRate), 1, fp);
  if (ferror(fp)) {
    printf(writeErrorMsg);
    abort();
  }

  for (i=0; i<NUM_OPCODES; i++) {
    /* Clear the buffer before we save it to avoid later nastiness. */
    memset(opname, 0, MAX_OPCODE_NAME_SIZE);
    (*gOpcodes[i])(0, opname); /* Get the name of the current opcode. */
    fwrite(opname, sizeof(char), MAX_OPCODE_NAME_SIZE, fp);
    if (ferror(fp)) {
      printf(writeErrorMsg);
      abort();
    }
  }
}

void GlobalsRestore(FILE *const fp)
{
  int i, j;
  char opname1[MAX_OPCODE_NAME_SIZE], opname2[MAX_OPCODE_NAME_SIZE];
  void  (*tempOpcodes[NUM_OPCODES])(const short the_cpu,
                                    char *const name);

  fread(&gRandData, sizeof(gRandData), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gSliceHead, sizeof(gSliceHead), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gFreeHead, sizeof(gFreeHead), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gInstsExecuted, sizeof(gInstsExecuted), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gPenalty, sizeof(gPenalty), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gNoOpZero, sizeof(gNoOpZero), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gNoOpOne, sizeof(gNoOpOne), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gSoupFill, sizeof(gSoupFill), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gNumCells, sizeof(gNumCells), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gOpsPerSlice, sizeof(gOpsPerSlice), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gThreshold, sizeof(gThreshold), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gCPUFailRate, sizeof(gCPUFailRate), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  fread(&gDataMutationRate, sizeof(gDataMutationRate), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  /* Read in the opcode name and find the function pointer for that opcode. */
  for (i=0; i<NUM_OPCODES; i++) {
    fread(opname1, sizeof(char), MAX_OPCODE_NAME_SIZE, fp);
    if (ferror(fp)) {
      printf(readErrorMsg);
      abort();
    }
    for (j=0; j<NUM_OPCODES; j++) {
      (*gOpcodes[j])(0, opname2); /* Get the name of an opcode */
      if (!strcmp(opname1,opname2)) {
        tempOpcodes[i] = gOpcodes[j];
        break;
      }
    }
    if (j == NUM_OPCODES) { /* We went through them all. */
      printf("Unknown opcode, %s\n", opname1);
      abort();
    }
  }

  /* Set the global array to match the file. */
  for (i=0; i<NUM_OPCODES; i++) {
    gOpcodes[i] = tempOpcodes[i];
  }
}


/* Determine if two genomes are identical. Returns 1 if the same,
   0 if they differ. Used by SaveOrganisms. */
int GenCompare(const short cpu1, const short cpu2)
{
  short i, j;

  /* If their sizes aren't the same, then they can't be identical. */
  if (gCpus[cpu1].hsize != gCpus[cpu2].hsize) {
    return (0);
  }

  /* Compare the genomes line by line. */
  for (i=gCpus[cpu1].home, j=gCpus[cpu2].home;
       i<gCpus[cpu1].home + gCpus[cpu1].hsize;
       i++, j++) {
    if (gSoup[i] != gSoup[j]) {
      return(0); /* Oops, found a mismatch. */
    }
  }

  /* They must be identical. */
  return(1);
}

/* Writes out a genome to disk, in the form of a seed file so it can
   be loaded by the user later, if desired. Used by SaveOrganisms. */

void WriteGenome(const short keeper, const short number)
{
  int i;
  FILE *fp;
  char opname[MAX_OPCODE_NAME_SIZE], filename[80];

  /* The filename format is as follows: the size of the genome, the
     number of examples of it in the population, and the first CPU
     index it appears at in the array. (The last is to provide a unique
     ID to differentiate between genomes that are the same size and
     frequency. */
  sprintf(filename, "%d-%d-%d.gen", gCpus[keeper].hsize, number, keeper);
  fp = fopen(filename, "w");
  if (NULL == fp) {
    printf("Problem creating genfile %s\n", filename);
    abort();
  }
  fprintf(fp, "; Home: %d, Size: %d - Child: %d, Size: %d\n",
          gCpus[keeper].home, gCpus[keeper].hsize,
          gCpus[keeper].child, gCpus[keeper].csize);
  fprintf(fp, "; Registers - ax: %d, bx: %d, cx: %d, dx: %d\n",
          gCpus[keeper].ax, gCpus[keeper].bx,
          gCpus[keeper].cx, gCpus[keeper].dx);
  fprintf(fp, "; IP: %d, Span: %d\n", gCpus[keeper].ip, gCpus[keeper].span);
  fprintf(fp, "; Flag: %d, Stack pointer: %d\n", gCpus[keeper].fl,
          gCpus[keeper].sp);
  if (gCpus[keeper].sp != STACK_EMPTY) {
    for (i=0; i<=gCpus[keeper].sp; i++) {
      fprintf(fp, "; st[%d]: %d\n", i, gCpus[keeper].st[i]);
    }
  }

  fprintf(fp, "%d\n%d\n", gCpus[keeper].hsize, gCpus[keeper].home);

  for (i=(int)(gCpus[keeper].home);
        i<(int)(gCpus[keeper].home+gCpus[keeper].hsize); i++) {
    (*gOpcodes[SafeReadSoup(i)])(0, opname);
    fprintf(fp, "%-8s (%d)\n", opname, SafeReadSoup(i));
  }
 
  fclose(fp);
}

/* Go through the CPU array. First, ignore all CPUs that are not
   currently alive. Then, examine each genome in turn, writing out
   all unique ones to disk. */
void SaveOrganisms(void)
{
  short current, used[NUM_CPUS];
  unsigned short number;
  int i, j;

  /* Initialize the marker array. */
  for (i=0; i<NUM_CPUS; i++) {
    used[i] = UNUSED;
  }

  /* The ones on the freelist aren't active, skip them. */
  current = gFreeHead;
  while (-1 != current) {
    used[current] = USED;
    current = gCpus[current].fl;
  }

  /* Okay, now the nitty gritty. Scan through the cpus, finding new genomes
     to save to disk. */
  for (i=1; i<NUM_CPUS; i++) {
    if (UNUSED == used[i]) {
      number = 0;
      current = (short)i;
      for (j=(int)current; j < NUM_CPUS; j++) {
        if (GenCompare(current, (short)j)) {
          used[j] = USED; /* Skip all the ones that are identical to this. */
          number++;
        }
      }
      if (number > gThreshold) {
        WriteGenome(current, number); /* This one's going down in history. */
      }
    }
  }
}

/* Make sure the name of a state file is in the correct format. */
void RectifyName(char *buffer, char *filename);

void RectifyName(char *buffer, char *filename)
{
  int len;

  len = (int) strlen(filename);
  if (0 == len) {
    /* It's an invalid filename. Give it a default. */
    sprintf(buffer, "state.st");
  }
  else {
    if ((len < 3) || strcmp(&filename[len-3], ".st")) {
      /* If the filename doesn't end in ".st", add it. */
      sprintf(buffer, "%s%s", filename, ".st");
    }
    else {
      sprintf(buffer, "%s", filename);
    }
  }
}

/* Save the state of the system to disk for later restoration. */
void SaveState(char *filename)
{
  long version;
  char thefile[80];
  FILE *fp;

  /* Make sure the name conforms to convention. */
  RectifyName(thefile, filename);

  fp = fopen(thefile, "wb");
  if (NULL == fp) {
    printf("Error saving to state file %s\n.", thefile);
    return;
  }

  /* Save a null char to the file - acts as a marker for what version
     of minev saved this file. (Yeah, like there will be later ones.) */
  version = 0;
  fwrite(&version, sizeof(version), 1, fp);
  GlobalsSave(fp);
  CpusSave(fp);
  SoupSave(fp);

  fclose(fp);
}

void RestoreState(char *filename)
{
  long version;
  char thefile[80];
  FILE *fp;

  RectifyName(thefile, filename);
  
  fp = fopen(thefile, "rb");
  if (NULL == fp) {
    printf("Error opening state file %s.\n", thefile);
    return;
  }

  fread(&version, sizeof(version), 1, fp);
  if (ferror(fp)) {
    printf(readErrorMsg);
    abort();
  }

  /* Make sure we're reading something viable. */
  if (version) {
    printf("This either isn't a state file or is from some later version\n");
    printf("of minev. I can't read it. Sorry.\n");
  }
  else {
    GlobalsRestore(fp);
    CpusRestore(fp);
    SoupRestore(fp);
  }

  fclose(fp);
}
