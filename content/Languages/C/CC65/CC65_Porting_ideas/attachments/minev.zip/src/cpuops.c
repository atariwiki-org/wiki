#include <string.h>

#include "consts.h"
#include "errors.h"
#include "structs.h"
#include "globals.h"

#include "soup.h"
#include "mutation.h"
#include "stack.h"
#include "cpu.h"
#include "cpuops.h"
#include "cpualloc.h"
#include "slicer.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/*  These are the operations that the minev cpus perform. They have two
    inputs, an short 'the_cpu' which is a subscript into the cpu
    array telling it which cpu to act on, and a char * 'name' which can
    be used to output the opcode's name.
    If 'name' is non-NULL, the opcode writes its name into the buffer,
    then exits without performing any further actions.
    If 'name' is NULL, the opcode does its thing. This generally consists
    of calling CpuFail() to see if the opcode will fail, then going ahead
    with the rest of the function. */

/* Note if you plan on implementing your own opcode set: Make It
   Bulletproof! Make sure it never corrupts memory or overflows an
   array or anything, no matter what input you get. In minev, things
   are *supposed* to go wrong. If there's an input your opcodes can't
   handle, I assure you it *will* come up, and you'll be sorry! :-> */

/*******************************************************************
*
* The no-ops that form templates.
*
*******************************************************************/

void nop0(const short the_cpu, char *const name) {
  char *id = "nop0";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }
}

void nop1(const short the_cpu, char *const name) {
  char *id = "nop1";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }
}

/*******************************************************************
*
* Stack manipulation.
*
*******************************************************************/

/* These four functions push different registers onto the stack, if there's
   space available on the stack. */

void pusha(const short the_cpu, char *const name) {
  char *id = "pusha";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].ax);
    break;
  case FAIL_PLUS: /* push twice */
    push(the_cpu, gCpus[the_cpu].ax);
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].ax);
    break;
  }

}

void pushb(const short the_cpu, char *const name) {
  char *id = "pushb";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].bx);
    break;
  case FAIL_PLUS: /* push twice */
    push(the_cpu, gCpus[the_cpu].bx);
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].bx);
    break;
  }
}

void pushc(const short the_cpu, char *const name) {
  char *id = "pushc";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].cx);
    break;
  case FAIL_PLUS: /* push twice */
    push(the_cpu, gCpus[the_cpu].cx);
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].cx);
    break;
  }
}

void pushd(const short the_cpu, char *const name) {
  char *id = "pushd";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].dx);
    break;
  case FAIL_PLUS: /* push twice */
    push(the_cpu, gCpus[the_cpu].dx);
    gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].dx);
    break;
  }
}

/* These four instructions pop the contents of the stack into various
   registers, if there's anything on the stack to pop. */

void popa(const short the_cpu, char *const name) {
  char *id = "popa";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].ax));
    break;
  case FAIL_PLUS: /* push twice */
    pop(the_cpu, &(gCpus[the_cpu].ax));
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].ax));
    break;
  }
}

void popb(const short the_cpu, char *const name) {
  char *id = "popb";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].bx));
    break;
  case FAIL_PLUS: /* push twice */
    pop(the_cpu, &(gCpus[the_cpu].bx));
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].bx));
    break;
  }
}

void popc(const short the_cpu, char *const name) {
  char *id = "popc";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].cx));
    break;
  case FAIL_PLUS: /* push twice */
    pop(the_cpu, &(gCpus[the_cpu].cx));
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].cx));
    break;
  }
}

void popd(const short the_cpu, char *const name) {
  char *id = "popd";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* push nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].dx));
    break;
  case FAIL_PLUS: /* push twice */
    pop(the_cpu, &(gCpus[the_cpu].dx));
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].dx));
    break;
  }
}

/* This swaps the top element on the stack with the one immediately below
   it, assuming there are at least two elements on the stack. */

void swap(const short the_cpu, char *const name) {
  char *id = "swap";
  short temp;
  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* No swapping this time. */
    break;
  case NO_FAIL: /* Swap top and second */
    if ((gCpus[the_cpu].sp >=1) && (gCpus[the_cpu].sp != STACK_EMPTY)) {
      temp = gCpus[the_cpu].st[gCpus[the_cpu].sp];
      gCpus[the_cpu].st[gCpus[the_cpu].sp] =
                            gCpus[the_cpu].st[gCpus[the_cpu].sp-1];
      gCpus[the_cpu].st[gCpus[the_cpu].sp-1] = temp;
    }
    else {
      gCpus[the_cpu].fl = ER_STACK_OVERFLOW;
    }
    break;
  case FAIL_PLUS: /* Swap top and third */
    if ((gCpus[the_cpu].sp >=2) && (gCpus[the_cpu].sp != STACK_EMPTY)) {
      temp = gCpus[the_cpu].st[gCpus[the_cpu].sp];
      gCpus[the_cpu].st[gCpus[the_cpu].sp] =
                            gCpus[the_cpu].st[gCpus[the_cpu].sp-2];
      gCpus[the_cpu].st[gCpus[the_cpu].sp-2] = temp;
    }
    else {
      gCpus[the_cpu].fl = ER_STACK_OVERFLOW;
    }
    break;
  }
}

/* This instruction duplicates the top element on the stack, assuming
   there's room for another element on the stack. */

void dup(const short the_cpu, char *const name) {
  char *id = "dup";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* don't do a thing */
    break;
  case NO_FAIL: /* duplicate the top of the stack */
    if (gCpus[the_cpu].sp != STACK_EMPTY) {
      gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].st[gCpus[the_cpu].sp]);
    }
    else {
      gCpus[the_cpu].fl = ER_STACK_UNDERFLOW;
    }
    break;
  case FAIL_PLUS: /* dup twice (trip?) */
    if (gCpus[the_cpu].sp != STACK_EMPTY) {
      push(the_cpu, gCpus[the_cpu].st[gCpus[the_cpu].sp]);
      gCpus[the_cpu].fl = push(the_cpu, gCpus[the_cpu].st[gCpus[the_cpu].sp]);
    }
    else {
      gCpus[the_cpu].fl = ER_STACK_UNDERFLOW;
    }
    break;
  }    
}

/*******************************************************************
*
* Math and calculation functions.
*
*******************************************************************/

/* Increment the cx register. */

void inc(const short the_cpu, char *const name) {
  char *id = "inc";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx++;
    break;
  case FAIL_PLUS: /* add two */
    gCpus[the_cpu].cx += 2;
    break;
  }
}

/* Decrement the cx register. */

void dec(const short the_cpu, char *const name) {
  char *id = "dec";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx--;
    break;
  case FAIL_PLUS: /* subtract two */
    gCpus[the_cpu].cx -= 2;
    break;
  }
}

/* Set the cx register to zero. */

void zeroc(const short the_cpu, char *const name) {
  char *id = "zeroc";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx = 0;
    break;
  case FAIL_PLUS: /* set to one */
    gCpus[the_cpu].cx = 1;
    break;
  }
}

/* Flip the low-order bit of cx. Note that if the number in cx is even,
   this amounts to incrementing it by one; if the number is odd, this is
   equivalent to decrementing cx. */

void lowc(const short the_cpu, char *const name) {
  char *id = "lowc";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }
  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx ^= 1;
    break;
  case FAIL_PLUS: /* flip second-lowest bit */
    gCpus[the_cpu].cx ^= 2;
    break;
  }
}

/* Shift the cx register left one bit. Note that if cx overlows the top bit
   is lost. Typically this is equivalent to multiplying cx by two. */

void shl(const short the_cpu, char *const name) {
  char *id = "shl";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx <<= 1;
    break;
  case FAIL_PLUS: /* shift twice */
    gCpus[the_cpu].cx <<= 2;
    break;
  }
}

/* Add dx to cx. */

void add(const short the_cpu, char *const name) {
  char *id = "add";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx += gCpus[the_cpu].dx;
    break;
  case FAIL_PLUS: /* add twice */
    gCpus[the_cpu].cx += (2*gCpus[the_cpu].dx);
    break;
  }
}

/* Subtract dx from cx. */

void sub(const short the_cpu, char *const name) {
  char *id = "sub";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* no failure */
    gCpus[the_cpu].cx -= gCpus[the_cpu].dx;
    break;
  case FAIL_PLUS: /* add twice */
    gCpus[the_cpu].cx -= (2*gCpus[the_cpu].dx);
    break;
  }
}

/*******************************************************************
*
* Instruction pointer manipulation.
*
*******************************************************************/

/* If the flag is set, execute subsequent instruction, otherwise skip it. */

void ifl(const short the_cpu, char *const name) {
  char *id = "ifl";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* operate normally */
    if (ER_NO_ERROR == gCpus[the_cpu].fl) {
      gCpus[the_cpu].ip++;
    }
    break;
  case FAIL_PLUS: /* skip regardless */
    gCpus[the_cpu].ip++;
    break;
  }
}

/* If the cx register is zero, execute the next instruction, otherwise
   skip to the one after it. */

void ifz(const short the_cpu, char *const name) {
  char *id = "ifz";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* operate normally */
    if (0 != gCpus[the_cpu].cx) {
      gCpus[the_cpu].ip++;
    }
    break;
  case FAIL_PLUS: /* skip regardless */
    gCpus[the_cpu].ip++;
    break;
  }
}

/* Jump outward to template. The jump will go to the closest complementary
   template (if any).
     Note that the search functions return the address immediately after
   the located template - but if we just stuffed that number into the ip,
   it would get incremented before executing. So, we subtract one from the
   address returned by the search functions. It gets incremented back to
   the proper address before it's executed again.
    Yes, this is complicated - but either I did it this way, or I would
   have written two different search functions that returned slightly
   different values. Considering that code space was rather tight, this
   seemed to be the more reasonable course. */

void jmp(const short the_cpu, char *const name) {
  char *id = "jmp";
  short jump=0, forward, backward;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  jump = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Do nothing - don't jump */
    return;
  case NO_FAIL:  /* operate normally */
    break;
  case FAIL_PLUS: /* jump to wrong template, if any. */
    jump++;
    break;
  }

  gCpus[the_cpu].fl = ForwSoupSearch(jump, &forward);

  forward--; /* because the IP will be incremented */

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {

    gCpus[the_cpu].fl = BackSoupSearch(jump, &backward);

    if(ER_NO_ERROR == gCpus[the_cpu].fl) { /* found two - must choose */

      backward--; /* The IP will be incremented (backward != 0) */

      gCpus[the_cpu].ip = ((jump - backward) < (forward - jump) ?
                           (backward) : (forward));
    }
    else { /* only the forward one exists */
      gCpus[the_cpu].ip = forward;
      gCpus[the_cpu].fl = ER_NO_ERROR; /* flag was set by BackSoupSearch */
    }
  }
  else { /* couldn't find one looking forward */
    gCpus[the_cpu].fl = BackSoupSearch(jump, &backward);
    if(ER_NO_ERROR == gCpus[the_cpu].fl) { /* found one! */
      backward--;
      gCpus[the_cpu].ip = backward;
    }
  }
}

/* Jump forward to template. */

void jmpf(const short the_cpu, char *const name) {
  char *id = "jmpf";
  short jump=0, forward;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  jump = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Do nada */
    return;
  case NO_FAIL:
    break;
  case FAIL_PLUS: /* jump to wrong template, if any. */
    jump++;
    break;
  }

  gCpus[the_cpu].fl = ForwSoupSearch(jump, &forward);

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {
    gCpus[the_cpu].ip = --forward; /* because the IP will be incremented */
  }
}

/* Jump backward to template. */

void jmpb(const short the_cpu, char *const name) {
  char *id = "jmpb";
  short jump, backward;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  jump = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Do nada */
    return;
  case NO_FAIL:
    break;
  case FAIL_PLUS: /* jump to wrong template, if any. */
    jump++;
    break;
  }

  gCpus[the_cpu].fl = BackSoupSearch(jump, &backward);

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {
    gCpus[the_cpu].ip = --backward; /* because the IP will be incremented */
  }
}

/* Push the current ip onto the stack and jump to the template immediately
   following the 'call'. Used to access 'subroutines'.
   If there isn't enough room on the stack, the jump will still occur. Even
   if the jump succeeds, the flag will still be set to a stack error.
   Note one 'feature' of this implementation: even if there isn't a template
   after the 'call' instruction, the current ip is still pushed onto the
   stack. Some cells hit upon the trick of having a 'call' as their first
   statement, followed by a 'pop' instruction. This cost them an exception
   penalty, but allowed them to very quickly determine their starting
   address. I liked this trick so much that I decided to leave it in. */

void call(const short the_cpu, char *const name) {
  char *id = "call";
  short jump,forward, backward, tempflag=ER_NO_ERROR;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  jump = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Don't push anything, still jump */
    break;
  case NO_FAIL: /* push IP to stack, jump to template */
    tempflag = push(the_cpu, gCpus[the_cpu].ip);
    break;
  case FAIL_PLUS: /* jump to wrong template, if any. */
    tempflag = push(the_cpu, gCpus[the_cpu].ip);
    jump++;
    break;
  }

  gCpus[the_cpu].fl = ForwSoupSearch(jump, &forward);

  forward--; /* because the IP will be incremented */

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {

    gCpus[the_cpu].fl = BackSoupSearch(jump, &backward);

    if(ER_NO_ERROR == gCpus[the_cpu].fl) { /* found two - must choose */

      backward--; /* The IP will be incremented (backward != 0) */

      gCpus[the_cpu].ip = ((jump - backward) < (forward - jump) ?
                           (backward) : (forward));
    }
    else { /* only the forward one exists */
      gCpus[the_cpu].ip = forward;
      gCpus[the_cpu].fl = tempflag; /* if we flagged while pushing, restore */
    }
  }
  else { /* couldn't find one looking forward */
    gCpus[the_cpu].fl = BackSoupSearch(jump, &backward);
    if(ER_NO_ERROR == gCpus[the_cpu].fl) { /* found one! */
      backward--; /* The IP will be incremented (backward != 0 - why?) */
      gCpus[the_cpu].ip = backward;
    }
  }
}

/* Pop the top element of the stack into the cpu's instruction pointer.
   Note that, since the ip will be incremented before the next instruction
   is executed, this is equivalent to a jump to the instruction immediately
   *after* the address in the stack. Typically used to return from a 'call'
   instruction. */

void ret(const short the_cpu, char *const name) {
  char *id = "ret";

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  switch(CpuFail()) {
  case FAIL_MINUS: /* do nothing */
    break;
  case NO_FAIL: /* pop the stack into the cell's ip */
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].ip));
    break;
  case FAIL_PLUS: /* return to the wrong address, if any */
    pop(the_cpu, &(gCpus[the_cpu].ip));
    gCpus[the_cpu].fl = pop(the_cpu, &(gCpus[the_cpu].ip));
    break;
  }
}

/*******************************************************************
*
* "Sensory" functions.
*
*******************************************************************/

/* Search outward for template, put result (if any) in ax. */

void adr(const short the_cpu, char *const name) {
  char *id = "adr";
  short start, forward, backward;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  start = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Do nothing */
    return;
  case NO_FAIL: /* find template */
    break;
  case FAIL_PLUS: /* find wrong template, if any. */
    start++;
    break;
  }

  
  gCpus[the_cpu].fl = ForwSoupSearch(start, &forward);

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {

    gCpus[the_cpu].fl = BackSoupSearch(start, &backward);

    if(ER_NO_ERROR == gCpus[the_cpu].fl) { /* found two - must choose */
      gCpus[the_cpu].ax = ((start - backward) < (forward - start) ?
                           (backward) : (forward));
    }
    else { /* only the forward one exists */
      gCpus[the_cpu].ax = forward;
      gCpus[the_cpu].fl = ER_NO_ERROR;
    }
  }
  else { /* couldn't find one looking forward */
    gCpus[the_cpu].fl = BackSoupSearch(start, &backward);
    if(ER_NO_ERROR == gCpus[the_cpu].fl) { /* found one! */
      gCpus[the_cpu].ax = backward;
    }
  }
}

/* Search forward in memory for template, result (if any) into ax. */

void adrf(const short the_cpu, char *const name) {
  char *id = "adrf";
  short start, forward;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  start = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Do nothing */
    return;
  case NO_FAIL: /* find template */
    break;
  case FAIL_PLUS: /* find wrong template, if any. */
    start++;
    break;
  }

  gCpus[the_cpu].fl = ForwSoupSearch(start, &forward);

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {
    gCpus[the_cpu].ax = forward;
  }
}

/* Search backward in memory for template, put result (if any) into ax. */

void adrb(const short the_cpu, char *const name) {
  char *id = "adrb";
  short start, backward;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  start = gCpus[the_cpu].ip;

  switch(CpuFail()) {
  case FAIL_MINUS: /* Do nothing */
    return;
  case NO_FAIL: /* find template */
    break;
  case FAIL_PLUS: /* find wrong template, if any. */
    start++;
    break;
  }

  gCpus[the_cpu].fl = BackSoupSearch(start, &backward);

  if(ER_NO_ERROR == gCpus[the_cpu].fl) {
    gCpus[the_cpu].ax = backward;
  }
}

/*******************************************************************
*
*  Biological functions. 
*
*******************************************************************/

/* Allocate amount of space in cx, as close as possible to ax, put resulting
   address (if any) into ax. */

void mal(const short the_cpu, char *const name) {
  char *id = "mal";
  short retadr;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  if (gCpus[the_cpu].csize > 0) {
    /* This cell already has a kid! */
    gCpus[the_cpu].fl = ER_ALLOC_CHILD_ALREADY;
  }
  else {
    if(!CpuFail()) { /* If cpu fails, do nothing */
      gCpus[the_cpu].fl = AllocSoup(gCpus[the_cpu].ax,
                                    gCpus[the_cpu].cx,
                                    &retadr);
      if (ER_NO_ERROR == gCpus[the_cpu].fl) {
        /* Success! */
        gCpus[the_cpu].ax = retadr;
        gCpus[the_cpu].child = retadr;
        gCpus[the_cpu].csize = gCpus[the_cpu].cx;
      }
    }
  }
}

/* Give a child its own cpu and hand over ownership of its soup to the kid.
   Allows the parent to allocate more memory. */

void div(const short the_cpu, char *const name) {
  char *id = "div";
  short newborn;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  if (gCpus[the_cpu].csize > 0) { /* does it even have a kid? */
    if (!CpuFail()) { /* If cpu fails, do nothing */

      newborn = NewCpu();
      if (newborn < 0) {
        gCpus[the_cpu].fl = ER_CPUPTR_NULL;
        return;
      }

      /* Initialize the new cell. */
      InitCpu(newborn, gCpus[the_cpu].csize, gCpus[the_cpu].child);

      /* Put it on the Slicer queue. */
      AddSliceCell(the_cpu, newborn);

      /* Make sure the parent knows the kids' on its own. */
      gCpus[the_cpu].child = 0;
      gCpus[the_cpu].csize = 0;

      /* Keep track of how many cells are in the soup. */
      gNumCells++;
    }
  }
  else {
    gCpus[the_cpu].fl = ER_DIV_NO_CHILD;
  }
}

/* Copy an instruction from [bx+cx] to [ax+cx]. */

void movii(const short the_cpu, char *const name) {
  char *id = "movii";
  short dest, source; /* Where the data will be written. */
  unsigned char data;

  /* If someone is just asking the opcode's name, output it and return. */
  if (name != NULL) {
    strcpy(name, id);
    return;
  }

  /* Figure out where we're copying from and to. Note that sometimes
     we copy the wrong instruction. */
  dest = gCpus[the_cpu].ax + gCpus[the_cpu].cx;
  source = gCpus[the_cpu].bx + gCpus[the_cpu].cx + CpuFail();

  /* Is the organism making sense? */
  if (dest < 0 || source < 0) {
    gCpus[the_cpu].fl = ER_BAD_ADDRESS;
    return;
  }

  /* Check ownership of soup involved. Is the address to be written
     unowned, in the creature itself, or in its kid? */
  if (!(gSoup[dest] & SOUP_ALLOCATE_MASK) ||
      ((gCpus[the_cpu].home <= dest) &&
       (dest < gCpus[the_cpu].home + gCpus[the_cpu].hsize)) ||
      ((gCpus[the_cpu].child <= dest) &&
       (dest < gCpus[the_cpu].child + gCpus[the_cpu].csize))) {

    if (!CpuFail()) { /* if we fail, do nada */
      data = MutReadSoup(source);
      WriteSoup(dest, data, MUTATE);
    }
  }
  else {
    gCpus[the_cpu].fl = ER_WRITE_NOT_OWNER;
  }
}
