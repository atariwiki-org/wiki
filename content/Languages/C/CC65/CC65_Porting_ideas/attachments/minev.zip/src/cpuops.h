#ifndef CPUOPS_H
#define CPUOPS_H 1

void nop0(const short the_cpu, char *const name);
void nop1(const short the_cpu, char *const name);
void pusha(const short the_cpu, char *const name);
void pushb(const short the_cpu, char *const name);
void pushc(const short the_cpu, char *const name);
void pushd(const short the_cpu, char *const name);
void popa(const short the_cpu, char *const name);
void popb(const short the_cpu, char *const name);
void popc(const short the_cpu, char *const name);
void popd(const short the_cpu, char *const name);
void movii(const short the_cpu, char *const name);
void inc(const short the_cpu, char *const name);
void dec(const short the_cpu, char *const name);
void zeroc(const short the_cpu, char *const name);
void lowc(const short the_cpu, char *const name);
void shl(const short the_cpu, char *const name);
void ifz(const short the_cpu, char *const name);
void jmp(const short the_cpu, char *const name);
void jmpf(const short the_cpu, char *const name);
void jmpb(const short the_cpu, char *const name);
void call(const short the_cpu, char *const name);
void ret(const short the_cpu, char *const name);
void adr(const short the_cpu, char *const name);
void adrb(const short the_cpu, char *const name);
void adrf(const short the_cpu, char *const name);
void mal(const short the_cpu, char *const name);
void div(const short the_cpu, char *const name);
void swap(const short the_cpu, char *const name);
void dup(const short the_cpu, char *const name);
void add(const short the_cpu, char *const name);
void sub(const short the_cpu, char *const name);
void ifl(const short the_cpu, char *const name);

#endif
