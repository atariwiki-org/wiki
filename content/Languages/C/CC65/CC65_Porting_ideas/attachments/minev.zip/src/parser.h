#ifndef PARSE_H
#define PARSE_H 1

void PrintHelp(void);
void PrintCpu(const short adr);
void PrintError(const unsigned short error);
char *EatWhiteSpace(char *inbuf);
short FindSoupOwner(const short adr);

void ShowSoup(const short adr, const short length);
short SeedSoup(char *const filename, short adr);

int ParseCommand(char *inbuf, char *command, char *arg1, char *arg2);
int DispatchCommand(const int nargs, char *command, char *arg1, char *arg2);

void Parser(void);

#endif
