#include "consts.h"
#include "mutation.h"
#include "globals.h"
#include "minrand.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/* Determine if a CPU should fail. If the result is a zero or one,
   (i.e. < 2), the cpu fails in some way. */
short CpuFail(void) {
  short randy;

  if (gCPUFailRate) {
    randy = RangedRandom(gCPUFailRate);
    if (randy < 2) {
      if (randy) {
        return(FAIL_PLUS);
      }
      else {
        return(FAIL_MINUS);
      }
    }
    else {
      return(NO_FAIL); /* Not failing this time */
    }
  }
  else {
    return(NO_FAIL);
  }
}

/* Generate a random bitmask for mutation purposes. Returns a mask with
   one bit flipped of the lower five. */
unsigned char GetMutMask(void) {
  unsigned char mask = 0x01;

  return(mask <<= RangedRandom(NUM_MUTMASKS));
}

/* Decide, based on gDataMutationRate, if a read or write to the soup
   will contain an error. If gDataMutationRate is zero, return an empty
   mask. */
unsigned char DataMutate(void) {
  /* Only mutate if gDataMutationRate != 0 */
  if (gDataMutationRate) {
    if (!RangedRandom(gDataMutationRate)) {
      return(GetMutMask());
    }
  }
  return(0); /* don't mutate */
}

/* Figure out a random lifespan for the creatures. No more than MAX_LIFESPAN,
   no less than MIN_LIFESPAN. */
short GetLifeSpan(void)
{
  return(RangedRandom(MAX_LIFESPAN-MIN_LIFESPAN) + MIN_LIFESPAN);
}
