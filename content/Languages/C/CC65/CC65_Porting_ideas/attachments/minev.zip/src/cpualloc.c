#include "structs.h"
#include "consts.h"
#include "globals.h"

#include "cpualloc.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/* These routines handle allocating and deallocating CPUs. Using 'malloc'
   would introduce a lot of overhead in a program that can ill afford
   overhead. This takes up less code space and uses no additional data
   space besides the CPUs themselves.
    Note: These routines use the "fl" field of the cpu to hold a "pointer"
   (subscript in the CPU array) to the next CPU on the "freeelist". They
   don't do any error checking at all - the OS should know what it's
   doing. */

/* Initialize the CPU array for allocation - called only once at the
   start of the program. */
void InitCPUAlloc(void) {
  short i;

  /* Always points to the first in the freelist. */
  gFreeHead = 0;

  /* Each CPU points to the next one in line - the last points back to
     zero. */
  for (i=0; i<NUM_CPUS; i++) {
    gCpus[i].fl = i+1;
  }

  /* Set special value in last one to mark as last in the list. */
  gCpus[NUM_CPUS-1].fl = -1;
}

/* Returns the subscript of an available CPU or zero if none are available. */
short NewCpu(void) {
  short temp;

  if (gFreeHead < 0) {
    return (-1); /* No more cpus. */
  }
  else {
    /* Return the first one on the freelist. */
    temp = gFreeHead;
    /* Advance gFreeHead to point to the next one. */
    gFreeHead = gCpus[gFreeHead].fl;
    return (temp);
  }
}

/* Put a CPU back onto the freelist. */
void FreeCpu(const short deadcpu) {

  /* Note: if gFreeHead == -1, this works correctly anyway. */
  gCpus[deadcpu].fl = gFreeHead;

  /* The dead cpu is the new head of the list. (LIFO, like a stack.) */
  gFreeHead = deadcpu;
}
