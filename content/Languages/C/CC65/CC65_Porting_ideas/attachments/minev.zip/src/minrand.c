#include "consts.h"
#include "globals.h"
#include "minrand.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

/* Linear congruential random number generator with numbers taken from
   "Numerical Recipes in C" by Press, Teukolsky, Vetterling, and Flannery.
   (Note: the code is *not* copied from there). */
long MinevRandom(void)
{
  gRandData.RandKey = A0 * (gRandData.RandKey % Q0) -
                           (R0 * (gRandData.RandKey / Q0));
  if (gRandData.RandKey < 0) {
    gRandData.RandKey += MODULUS;
  }
  return(gRandData.RandKey);
}

/* Start up the random number generator, fill up the shuffle table, and
   so on. */
void InitRandom(long seed)
{
  int i;

  /* Seeds less than or equal to zero are disallowed in the random
     number generator. */
  if (0 == seed) {
    seed = 1;
  }
  else if (seed < 0) {
    seed = -seed;
  }

  gRandData.RandKey = seed;
  for (i=0; i<NUM_SHUFFLES; i++) {
    gRandData.ShufTable[i] = MinevRandom();
  }
  gRandData.ShufAux = MinevRandom();
}

/* This is the function that the functions in 'mutation.c' call to get
   random numbers. */
short RangedRandom(const short max)
{
  int index;

  /* Generate the standard long random number, using Bays-Durham
     shuffling to improve the randomness of the sequence, taken from
     "Seminumerical Algorithms" by Knuth. */
  /* The ShufTable array has been previously initialized by InitRandom. */
  index = (int) (gRandData.ShufAux / BD_SCALE);
  gRandData.ShufAux = gRandData.ShufTable[index];
  gRandData.ShufTable[index] = MinevRandom();

  /* Scale the number to the range [0 ... max) */
  return((short) (gRandData.ShufAux / ((MODULUS/max)+1)));
}
