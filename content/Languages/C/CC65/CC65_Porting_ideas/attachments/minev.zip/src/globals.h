#ifndef GLOBALS_H
#define GLOBALS_H 1

#include <stdio.h> /* To get FILE type */
#include "structs.h"

/* For comments describing what these do, see "minev.c". */
extern void  (*gOpcodes[NUM_OPCODES])(const short the_cpu, char *const name);
extern CPU gCpus[NUM_CPUS];
extern unsigned char gSoup[SOUP_SIZE];
extern RandData gRandData;
extern short gSliceHead;
extern short gFreeHead;
extern unsigned char gNoOpZero, gNoOpOne;
extern short  gSoupFill;
extern unsigned short gNumCells;
extern unsigned long gInstsExecuted;
extern short gPenalty;
extern short  gOpsPerSlice;
extern unsigned short gThreshold;
extern short  gCPUFailRate;
extern short  gDataMutationRate;
extern FILE *gInputFile;
#endif
