#ifndef MUTATION_H
#define MUTATION_H 1

short CpuFail(void);
unsigned char GetMutMask(void);
unsigned char DataMutate(void);
short GetLifeSpan(void);

#endif
