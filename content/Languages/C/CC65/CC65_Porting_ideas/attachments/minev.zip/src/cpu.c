#include <assert.h>

#include "consts.h"
#include "errors.h"
#include "structs.h"
#include "globals.h"
#include "soup.h"

#include "slicer.h"
#include "soup.h"
#include "cpuops.h"
#include "cpu.h"
#include "cpualloc.h"
#include "minrand.h"
#include "mutation.h"

 /* This software is provided "as-is", with ABSOLUTELY NO WARRANTY, EXPRESS
    OR IMPLIED, INCLUDING (BUT NOT LIMITED TO) THE IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. No matter *what*
    happens, the author is *not* *responsible*.
     There, the scary words are over. I can also point out that this
    software is released into the public domain. You can do *anything* you
    want with it, including modify it to your hearts content, print it out
    and line birdcages, or sell it for an obscene profit (yeah, right -
    good luck on that one). As a simple courtesy, I ask that if you find it
    enjoyable, you drop me a line at inglesra@frc.com, but you're not
    obligated to do even that. I hope you enjoy minev! */

#define Fetch(x) SafeReadSoup(x)

/* Randomly swaps the opcodes around, so that numbers in the soup point
   to different opcodes. */

void ReorderOps(void)
{
  /* "temp" is an opcodes function pointer. */
  void  (*temp)(const short the_cpu, char *const name);
  short i, first, second;

  /* Perform many random swaps. */
  for (i=0; i<NUM_OPCODES; i++) {

    /* Get a couple random opcodes to swap. */
    first = RangedRandom(NUM_OPCODES);
    second = RangedRandom(NUM_OPCODES);
    while (first == second) { /* Don't waste time swapping the same one. */
      second = RangedRandom(NUM_OPCODES);
    }
     
    /* Make sure the no-ops are accounted for. This is probably too
       complicated. */
    if (IsNoOp(first)) {
      if (IsNoOp(second)) {
        /* Swap the NoOp pointers. */
        i = gNoOpOne;
        gNoOpOne = gNoOpZero;
        gNoOpZero = (unsigned char) i;
      }
      else {
        /* Only 'first' is a no-op. */
        if (gNoOpOne == first) {
          gNoOpOne = second;
        }
        else {
          assert(gNoOpZero == first);
          gNoOpZero = second;
        }
      }
    }
    else {
      if (IsNoOp(second)) {
        /* Only 'second' is a no-op. */
        if (gNoOpOne == second) {
          gNoOpOne = first;
        }
        else {
          assert(gNoOpZero == second);
          gNoOpZero = first;
        }
      }
    }

    /* Actually swap the opcodes. */
    temp = gOpcodes[first];
    gOpcodes[first] = gOpcodes[second];
    gOpcodes[second] = temp;
  }

  /* Make sure the no-ops are within one bit-flip of each other. This
     speeds up the evolution somewhat. */
  first = gNoOpOne ^ GetMutMask(); /* Flip a bit. */
  second = gNoOpZero;
  temp = gOpcodes[first];
  gOpcodes[first] = gOpcodes[second];
  gOpcodes[second] = temp;
  gNoOpZero = first;
}

/* Initialize a newborn cpu with its home, lifespan, stack, etc. */
void InitCpu(const short cpu, const short size,
             const short home)
{
#if ZERO_CPU
  gCpus[cpu].ax = gCpus[cpu].bx = gCpus[cpu].cx = gCpus[cpu].dx = 0;
#endif
  gCpus[cpu].ip = home;
  gCpus[cpu].span = GetLifeSpan();
  gCpus[cpu].home = home;
  gCpus[cpu].child = 0;
  gCpus[cpu].hsize = size;
  gCpus[cpu].csize = 0;
  gCpus[cpu].sp = STACK_EMPTY;
  gCpus[cpu].fl = ER_NO_ERROR;
}

/* Give a cpu a timeslice to play with. */
void DoSlice(void) {
  int i;
  unsigned char opcode;

  for (i=0; i<gOpsPerSlice; i++) {

    /* Get the opcode from the soup, stripping off any extra bits in
       front. */
    opcode = Fetch(gCpus[gSliceHead].ip);

    gCpus[gSliceHead].fl = ER_NO_ERROR; /* clear the flag */

    /* Perform the actual operation. */
    assert(opcode < NUM_OPCODES);
    (*gOpcodes[opcode])(gSliceHead, NULL); /* Call the function pointer */
    gInstsExecuted++;

    /* Move on to the next instruction. */
    gCpus[gSliceHead].ip++;

    /* Handle overflow of ip, weird opcode results, etc. */
    if (gCpus[gSliceHead].ip < 0) {
      gCpus[gSliceHead].ip = 0;
    }

    /* These cells aren't immortal; all must one day perish. */
    gCpus[gSliceHead].span--;

    /* If we set the flag, bump the CPU closer to doom. */
    if (gCpus[gSliceHead].fl != ER_NO_ERROR) {
      gCpus[gSliceHead].span -= gPenalty;
    }
  }

  /* So if the cell died... */
  if (gCpus[gSliceHead].span <= 0) {
    KillCell(gSliceHead);   /* Advances gSliceHead */
  }
  else
  {
    gSliceHead = gCpus[gSliceHead].snext;
  }
}

/* Called when a cells lifespan is <= 0. Removes it from the slicer
   queue, frees up its soup and frees the cpu. */
void KillCell(const short victim)
{
  /* Take it off the Slicer queue. */
  DeleteSliceCell(victim); /* Advances gSliceHead */

  /* Free up the soup it lives in. */
  DeallocSoup(gCpus[victim].home, gCpus[victim].hsize);

  /* If it has a kid, it's now stillborn. */
  if (gCpus[victim].csize) {
    DeallocSoup(gCpus[victim].child, gCpus[victim].csize);
  }

  /* Return the cpu to the freelist. */
  FreeCpu(victim);

  gNumCells--; /* One less cell in the soup. */
}

/* Determine if an opcode represents one of the no-ops. */
short IsNoOp(const unsigned char opcode) {
  if (opcode == gNoOpZero || opcode == gNoOpOne) {
    return(IS_NOOP);
  }
  else {
    return(NOT_NOOP);
  }
}

/* Given an opcode for one of the two no-ops, return the opcode
   associated with the other no-op. This is used when searching for
   templates in the soup. Note: performs no error checking. */
unsigned char OtherNoOp(const unsigned char opcode) {
  if (opcode == gNoOpZero) {
    return(gNoOpOne);
  }
  else {
    assert(opcode == gNoOpOne);
    return(gNoOpZero);
  }
}
