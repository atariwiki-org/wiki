#ifndef CPU_H
#define CPU_H 1

void InitCpu(const short cpu, const short size,
             const short home);
void KillCell(const short victim);
void DoSlice(void);
short IsNoOp(const unsigned char opcode);
unsigned char OtherNoOp(const unsigned char opcode);
void ReorderOps(void);

#endif
