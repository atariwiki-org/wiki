#ifndef SOUP_H
#define SOUP_H 1

void InitSoup(void);

/* Accessing soup. */
#define SafeReadSoup(x) (gSoup[x] & SOUP_STRIP_MASK)
#define MutReadSoup(x) ((gSoup[x] & SOUP_STRIP_MASK) ^ DataMutate())
void WriteSoup(const short adr, const unsigned char val, const char mutate);

/* Allocation of space for organisms to live. */
short AllocSoup(const short pref, const short size, short *const retadr);
void DeallocSoup(const short adr, const short size);

/* Search soup for templates. */
short ForwSoupSearch(const short start, short *const retadr);
short BackSoupSearch(const short start, short *const retadr);

#endif
