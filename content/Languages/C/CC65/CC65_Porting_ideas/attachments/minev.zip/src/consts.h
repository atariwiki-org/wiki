#ifndef CONSTS_H
#define CONSTS_H 1

#ifndef NULL
#define NULL ((void *)0)
#endif

/****************************************************************
*
*  Change at will. These affect operation of the system.
*
****************************************************************/

/* If ZERO_SOUP is nonzero, the soup is cleaned out before it is used
   the first time. Otherwise, the soup will probably contain random
   garbage opcodes. An extra source of randomness if you want it. */
#define ZERO_SOUP                              1

/* If ZERO_CPU is nonzero, the registers of a cpu will be cleared
   before a cell starts executing. Otherwise, the registers will most
   likely contain random garbage. Again, if you want more randomness,
   here's your chance. */
#define ZERO_CPU                               1

/****************************************************************
*
*  Change with caution. Could muck things up outrageously.
*
****************************************************************/

/* How far an organism can search the soup for a template. */
#define SOUP_TEMPLATE_SEARCH                 96

/* How far an organism can search when allocating space. */
#define SOUP_ALLOC_SEARCH                  2048

/* The most space an organism can allocate. */
#define MAX_ALLOC_SIZE                      256

/* The smallest size a cell can allocate. Mutants often (*very* often)
   allocate lots of itty-bitty useless cells - this minimizes that sort
   of behavior. The smallest self-contained moderately-viable organism
   observed is about 20 instructions long. Some parasites of size 11 have
   been observed but they are fairly rare and not terribly interesting.
   16 seems a reasonable limit... */
#define MIN_ALLOC_SIZE                        16

/* How big a template can be. */
#define MAX_TEMPLATE_SIZE                      8

/* If you increase the stack size the Cpu struct will be more than 32
   bytes long, which could really muck up the alignment of the structs. */
#define STACK_SIZE      5

/* The minimum lifespan an organism may receive. Raise this number to be
   merciful, lower it to be harsh. Don't raise it above 32767. Make sure
   MIN_LIFESPAN < MAX_LIFESPAN. */
#define MIN_LIFESPAN                        2000

/* The maximum lifespan an organism may receive. Raise this number to be
   merciful, lower it to be harsh. Don't raise it above 32767. Make sure
   MIN_LIFESPAN < MAX_LIFESPAN. */
#define MAX_LIFESPAN                        5000

/* How many instructions an organism loses off its lifespan if it raises
   a cpu exception. The higher the number, the harsher the selection
   against exceptions. */
#define DEFAULT_EXCEP_PENALTY                 10

/* How many operations a cell can execute in a given timeslice. */
#define DEFAULT_OPS_PER_SLICE                 10

/* How many of a type of genome must be present before the system will
   save it out to disk. */
#define DEFAULT_MIN_WRITE_THRESHOLD            5

/* How frequently mutations occur. If DEFAULT_CPU_FAIL_RATE is set to
   M, the CPUs fail 1 out of every M instructions executed. If
   DEFAULT_TRANS_ERR_RATE is set to N, 1/N soup manipulations (reading
   or writing) contain a mutation.
   Setting either to zero disables that form of mutation. */
#define DEFAULT_CPU_FAIL_RATE              20000
#define DEFAULT_TRANS_ERR_RATE              4000

/* The maximum nuber of CPUs available for organisms. Since there is no
dynamically-allocated data, this number can be increased arbitrarily
until you run out of data space. E.g., in DOS with Power C, you can have
at most XXX cpus before you fill up the data segment. */
#define NUM_CPUS                            600

/****************************************************************
*
* Don't screw with these. Fundamental constants of the minev "OS".
*
****************************************************************/

/* The soup is currently as big as you can make it while using a signed
   int for addressing. If you make it any bigger you'll have to make
   the CPU registers and stack unsigned ints at least.
   Note that you can only have 64K of data in a program for Minix on a
   {80x86: 0<=x<3}, so 32K is already half of the available data. In
   other words... don't mess with this number. */
#define SOUP_SIZE                          32767

#define MAX_OPCODE_NAME_SIZE                   8
#define NUM_OPCODES                           32
#define NUM_MUTMASKS                           4  /* 0-4 = 5, really */

#define FAIL_PLUS                              1
#define NO_FAIL                                0
#define FAIL_MINUS                            -1

#define SOUP_ALLOCATE_MASK ((unsigned char)0x80)
#define SOUP_STRIP_MASK    ((unsigned char)0x1f)
/* These two aren't used (yet). */
#define SOUP_EXEC_MASK     ((unsigned char)0x40)
#define SOUP_READ_MASK     ((unsigned char)0x20)

#define STACK_EMPTY               (STACK_SIZE+1)

#define MUTATE                                 1
#define NO_MUTATE                              0
#define IS_NOOP                                1
#define NOT_NOOP                               0
#define USED                                   1
#define UNUSED                                 0

/* For the random number generator. */
#define MODULUS   2147483647L /* Also the max size of a random number */
/* How large the Bays-Durham shuffle table should be. You can make this
   larger if you want, but so far as I can tell it doesn't make much
   difference. */
#define NUM_SHUFFLES  8
/* Used to generate a random index into the Bays-Durham shuffle table.
   (The +1 ensures that numbers close to the mudulus will not be rounded
   up to be equal to NUM_SHUFFLES.) */
#define BD_SCALE   ((MODULUS/NUM_SHUFFLES)+1)

/* Constants for the linear congruential RNG. */
#define A0        16807
#define Q0        127773
#define R0        2836

#endif
