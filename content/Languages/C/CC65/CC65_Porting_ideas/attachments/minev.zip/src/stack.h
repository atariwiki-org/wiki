#ifndef STACK_H
#define STACK_H 1

short push(const short the_cpu, const short pushee);

short pop(const short the_cpu, short *const popee);

#endif
