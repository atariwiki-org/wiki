/*  RPN           v1.2          March 17, 1993                            */

/*  This is a program to emulate an RPN (Reverse Polish Notation)
    calculator with full functions of an HP-67, but with unlimited
    stack and program space.

    The stack is a null-terminated linked list whose first element is
    the 'X' member of the stack.

    Precision used is extended 80-bit floats with nineteen decimal
    digits and exponents ranging between 1e+/-4932.

    This program is copyright 1992 by Christopher Neufeld. The
    executable for this program contains runtime libraries copyrighted
    by the Byte Works.                                                */

/*  Implementation dependent function which might have to be changed
    when porting are:  goto_xy(),  clrscrn(),  cursoron(),  cursoroff(),
                       myfgets(),  clrtoeos(),  applesetup(),
                       applecloseup(), getkey(), Scrollup(), Scrolldown()

    This program is hard-wired to work on an 80x24 screen             */

#pragma debug 0
/* #pragma optimize 7 */         /* Optimization kills the parsep routine */
                                  /* by fouling up 'cmdreg'. Don't know why */
#pragma memorymodel 1              /* Large memory model */

#pragma keep "rpn"

#define BUILDCDA
                               /*     As a CDA the program will not clear the
                                      registers and stack when quitting, ie.
                                      it will be fully re-entrant             */

#ifdef BUILDCDA
#pragma cda "RPN Calculator" main closeup2
#pragma stacksize 256
#else
#pragma stacksize 8192
#endif

#ifdef BUILDCDA
#define LOCTYP static                 /* Because CDAs have only 256 bytes */
#else                                 /* of stack, we have to conserve by */
#define LOCTYP auto                   /* making local variables static    */
#endif


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <misctool.h>
#include <orca.h>
#include <sane.h>

#include "rpn.h"

#define VERSIONLABEL "v1.2"


const char fieldstr[10] = "%30s %30s";   /* FIELDWIDTH twice between % and s */


FILE *instream;               /* For reading instructions */
FILE *outstream;              /* For writing some output  */

segment "overlord";

extern struct pmem upperpmem;

struct pmem basepmem = {0, BREAK, 0.0, {""}, &upperpmem, NULL};
struct pmem upperpmem = {1, BREAK, 0.0, {""}, NULL, &basepmem};
                                  /* As many NULL strings as needed */

struct programcounter basectr = {&basepmem, NULL};

enum angles theta = deg;     /* How angles are expressed     */
enum displaytypes disp = fix;  /* Display mode used */
enum opmodes howdo = immed;  /* Where is input? */

void (*procstream)() = parser;    /* Which function should parse input */

floatval pival;        /* pi, used by various routines */

struct rstack *xval=NULL;   /* The value of the 'x' element of the stack     */
struct rmem   *memrroot=NULL;
struct programcounter *progctr=&basectr;
struct flags  *flagroot=NULL;

int skipnext = 0;     /* Clear before each call, comes back true if it
                         should skip the next step in a program              */
int memchg = 0;       /* Clear before each call, comes back true if any
                         memory has been altered                             */
int redrawstck = 0;   /* Clear before each call, comes back true if the
                         stack should be manually redrawn                    */


int labelcode;
floatval lastrx = 0.0;
floatval irregister = 0.0;
floatval sumx=0.0;
floatval sumx2=0.0;
floatval sumy=0.0;
floatval sumy2=0.0;
floatval sumxy=0.0;                        /* Statistical registers */
floatval nstat=0;                          /* Statistical counter   */

#define SUMXSTR "sumx"
#define SUMX2STR "sumx2"
#define SUMYSTR "sumy"
#define SUMY2STR "sumy2"
#define SUMXYSTR "sumxy"
#define NSTATSTR "nstat"

int digits=5;                              /* Number of digits to display */
int refresh=0;                             /* Goes high if the screen needs
                                              complete refresh            */
int drawall=1;             /* Should entire stack be redrawn? No if unary op */
int drawxy=0;              /* If drawall=0 and drawxy=1, draw both x and y */
int sops=0;                /* Net stack operation imbalance                */
int endprog=0;             /* Should the program execution terminate?      */
int quitrpn=0;             /* Set when we're quitting RPN                  */
int keybdint=0;            /* Holds entry state of keyboard interrupts     */
int misctls=1;             /* Holds entry state of misc. tools             */

#ifndef BUILDCDA
int orcashell=0;           /* Is set if running an EXE from the ORCA shell */
#endif

#ifdef BUILDCDA
Word sanestat;
#endif

const char novalstr[FIELDWIDTH] = "                  0.0      ";  /* 20 spaces, then 7 */
const char errfmtstr[] = "%s  --  Press RETURN ";


segment "overlord";


void rpnerror(char *msg)
{
  goto_xy(0,INPUTLINE);
  BEEP;
  printf(errfmtstr, msg);
  do {} while ((getkey() & 0x7F) != 0x0D);   /* Wait for CRET */
}


void dispdigs(char *numwidth)
{
  char *ptr;
  int res,len;
  LOCTYP t_memtags reglab;

  if (strcmp(numwidth,INDLABEL) == 0) {
    sprintf(reglab,"%li",(long)irregister);
  }
  else strcpy(reglab,numwidth);
  res = strtol(reglab,&ptr,10);
  len = strlen(reglab);
  if (&reglab[len-1] != ptr && res >= 0 && res < MAXDIGS) {
    if (digits != res) {
      memchg = drawall = redrawstck = 1;
      digits = res;
    }
    else drawall = 0;
  }
  else BEEP;
}

void fixdisp()
{
  if (disp != fix) {
    memchg = redrawstck = drawall = 1;
    disp = fix;
  }
  else drawall = 0;
}

void scidisp()
{
  if (disp != sci) {
    memchg = redrawstck = drawall = 1;
    disp = sci;
  }
  else drawall = 0;
}

void engdisp()
{
  if (disp != eng) {
    memchg = redrawstck = drawall = 1;
    disp = eng;
  }
  else drawall = 0;
}

void hexdisp()
{
  if (disp != hex) {
    memchg = redrawstck = drawall = 1;
    disp = hex;
  }
  else drawall = 0;
}

void primsec()
{
  struct rmem *ptr;
  floatval hold;

  ptr = findrmem(SUMXSTR);
  hold = ptr->val;
  ptr->val = sumx;
  sumx = hold;
  ptr = findrmem(SUMX2STR);
  hold = ptr->val;
  ptr->val = sumx2;
  sumx2 = hold;
  ptr = findrmem(SUMYSTR);
  hold = ptr->val;
  ptr->val = sumy;
  sumy = hold;
  ptr = findrmem(SUMY2STR);
  hold = ptr->val;
  ptr->val = sumy2;
  sumy2 = hold;
  ptr = findrmem(SUMXYSTR);
  hold = ptr->val;
  ptr->val = sumxy;
  sumxy = hold;
  ptr = findrmem(NSTATSTR);
  hold = ptr->val;
  ptr->val = nstat;
  nstat = hold;
}

void clrprog()
{
  struct pmem *ptr1,*ptr2;
  struct programcounter *pctr1,*pctr2;

  ptr1 = &basepmem;
  ptr2 = ptr1->nextpmem;
  while (ptr2 != &upperpmem) {
    ptr1 = ptr2;
    ptr2 = ptr1->nextpmem;
    free(ptr1);
  }
  basepmem.nextpmem = &upperpmem;
  upperpmem.lastpmem = &basepmem;
  upperpmem.linenum = 1;
  pctr1 = progctr;
  pctr2 = pctr1->nextctr;
  while (pctr2 != NULL) {
    free(pctr1);
    pctr1 = pctr2;
    pctr2 = pctr1->nextctr;
  }
  progctr = &basectr;
  progctr->pctr = &basepmem;
  progctr->nextctr = NULL;
}

void progrpn()
{
  SaveScrn(0);    /*  Save the current screen  */
  howdo = prog;
  procstream = parsep;
  drawkeys();
  flushret();
  if (progctr->pctr == &upperpmem) progctr->pctr = upperpmem.lastpmem;
  drawpmem(0);
}

void loadprog()
{
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  LOCTYP FILE *holdstream;
  static longstr filename;
  char oskind;
  LOCTYP char msg1[] = "Need GS/OS to load programs";
  LOCTYP char msg2[] = "Error opening file";

  if (instream != stdin) return;    /* Can't nest 'load' statements */
  oskind = *((char *) OS_KIND);        /* What OS is active? */
  if (oskind != 1) {           /* ProDOS8 active */
    drawall = 0;
    rpnerror(msg1);
    return;
  }
  goto_xy(0,INPUTLINE);     /* Input line */
  clrtoeol();
  printf("File> ");
  filename[0] = 0;
  do {} while (mygets(filename, STRWIDTH-1, 0) == 1);
  holdstream = instream;
  if ((instream = fopen(filename,"r")) == NULL) {   /* File not found */
    drawall = 0;
    instream = holdstream;
    rpnerror(msg2);
    return;
  }
  howdo = read;
  procstream = parsep;
  flushret();
}

void saveprog()
{
  LOCTYP FILE *holdstream;
  static longstr filename;
  char *ptr;
  LOCTYP char oskind, mode, k1, k2;
  LOCTYP char msg1[] = "Need GS/OS to save programs/variables";
  LOCTYP char msg2[] = "Error opening file";
  LOCTYP unsigned long plow, phigh, pcurrent;
  LOCTYP struct pmem *pptr;
  LOCTYP struct rmem *mptr;
  LOCTYP enum opmodes holdhow;

  oskind = *((char *) OS_KIND);        /* What OS is active? */
  if (oskind != 1) {           /* ProDOS8 active */
    drawall = 0;
    rpnerror(msg1);
    return;
  }
  mode = 1;
  plow = basepmem.linenum+1;        /* default to save entire program space */
  phigh = upperpmem.linenum-1;
  if (basepmem.nextpmem != &upperpmem) {
    do {
      goto_xy(0,INPUTLINE);     /* Input line */
      clrtoeol();
      printf("Standard save (1)  or  Special save (2)?  ");
      mode = getkey() & 0xFF;
    } while (mode != '1' && mode != '2');
    mode -= '0';
    k2 = 'y';         /* default to saving memory as well */
    if (mode == 2) {
      do {
        goto_xy(0,INPUTLINE);
        clrtoeol();
        printf("Save restricted range (1)  or  entire program space (2)?  ");
        k1 = getkey() & 0xFF;
      } while (k1 != '1' && k1 != '2');
      k1 -= '0';
      if (k1 == 1) {
        do {
          goto_xy(0,INPUTLINE);
          clrtoeol();
          printf("Starting at line: (1-%ul)  ",upperpmem.linenum-1);
          filename[0] = 0;
          do {} while (mygets(filename, STRWIDTH-1, 0) == 1);
          plow = strtoul(filename, &ptr, 10);
          if (*ptr) {
            plow = 0;
            continue;
          }
          goto_xy(0,INPUTLINE);
          clrtoeol();
          printf("Ending at line: (1-%ul)  ",upperpmem.linenum-1);
          filename[0] = 0;
          do {} while (mygets(filename, STRWIDTH-1, 0) == 1);
          phigh = strtoul(filename, &ptr, 10);
          if (*ptr) {
            phigh = 0;
            continue;
          }
        } while (plow < 1 || phigh >= upperpmem.linenum || plow > phigh);
      }
      do {
        goto_xy(0,INPUTLINE);
        clrtoeol();
        printf("Save memory? (y/n)  ");
        k2 = getkey() & 0xFF;
      } while (k2 != 'y' && k2 != 'n' && k2 != 'N' && k2 != 'Y');
      k2 = tolower(k2);
    }
  }
  goto_xy(0,INPUTLINE);
  clrtoeol();
  printf("File to save> ");
  filename[0] = 0;
  do {} while (mygets(filename, STRWIDTH-1, 0) == 1);
  holdstream = outstream;
  if ((outstream = fopen(filename,"a")) == NULL) {   /* Open failed */
    drawall = 0;
    outstream = holdstream;
    rpnerror(msg2);
    return;
  }
  holdhow = howdo;
  howdo = write;
  if (plow <= phigh) {
    sprintf(filename, ".%lu", plow);
    setpctr(filename);
    pptr = progctr->pctr;
    while (pptr != NULL && pptr->linenum <= phigh) {
      writep(pptr);
      fprintf(outstream, "\n");
      pptr = pptr->nextpmem;
    }
  }
  if (k2 == 'y') {
    fprintf(outstream, "usrmode\n");
    mptr = memrroot;
    while (mptr != NULL) {
      if (mptr->val != 0.0) {
        fprintf(outstream, "%.*le\n", MAXDIGS-1, mptr->val);
        fprintf(outstream, "sto %s\n", mptr->memtag);
        fprintf(outstream, "clx\n");
      }
      mptr = mptr->nextmem;
    }
  }
  fclose(outstream);
  outstream = holdstream;
  howdo = holdhow;
}

void usrmode()
{
  howdo = immed;
  procstream = parser;
}

void gotolab(char *label)
{
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  static longstr outputs;

  if (setpctr(label) == 0) {
    strcpy(outputs, "Label not found: ");
    strcat(outputs, label);
    rpnerror(outputs);
    endprog = 1;
    return;
  }
}

int setpctr(char *label)
/* Returns '1' if successful, '0' if not                          */
{
  struct pmem *ctr;
  LOCTYP unsigned long oldlinenum, srchnum, i;
  char *chkr;

  if (basepmem.nextpmem == &upperpmem) return 0; /* Exception handler, no program */
  oldlinenum = (progctr->pctr)->linenum;
  if (badlabel(label) == 1) {  /* go to a line number */
    srchnum = strtoul(label+1, &chkr, 10);
    if (*chkr || srchnum >= upperpmem.linenum) {
      rpnerror("Illegal format/range for absolute goto.");
      return 0;
    }
    ctr = progctr->pctr;
    if (oldlinenum == srchnum) return 1;
    if (oldlinenum > srchnum) {
      for (i=1;i<=oldlinenum-srchnum;i++) ctr = ctr->lastpmem;
      progctr->pctr = ctr;
    } else {
      for (i=1;i<=srchnum-oldlinenum;i++) ctr = ctr->nextpmem;
      progctr->pctr = ctr;
    }
    return 1;
  }
  ctr = (progctr->pctr);
  do {
    ctr = ctr->nextpmem;
    if (ctr == NULL) ctr = &basepmem;
    if (ctr->commandcode != labelcode) continue;
    if (ctr->labels[0][0] == label[0] && strcmp(ctr->labels[0],label) == 0) {
           /* Found it */
      progctr->pctr = ctr;
      return 1;
    }
  } while (ctr->linenum != oldlinenum);
  return 0;                              /* Didn't find it */
}

void gosublab(char *label)
{
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  struct programcounter *oldctr,*newpctr;
  static longstr outputs;

  oldctr = progctr;
  newpctr = (struct programcounter *) malloc(sizeof(struct programcounter));
  if (newpctr == NULL) {
    rpnerror("Memory allocation failure in 'gosublab'");
    endprog = 1;
    return;
  }
  newpctr->nextctr = progctr;
  newpctr->pctr = progctr->pctr;
  progctr = newpctr;
  if (setpctr(label) == 0) {          /* Didn't find it, so give back the memory */
    progctr = oldctr;
    free(newpctr);
    strcpy(outputs, "Label not found: ");
    strcat(outputs, label);
    rpnerror(outputs);
    endprog = 1;
  }
}

void runprog(char *parms[ARGSONLINE])
/* Run the program from the current program counter if no parameters. If
   there is a parameter passed, clear the return stack and then run from
   that label. Currently undefined for more than one parameter passed.   */
{
  LOCTYP int i, runmode;
  static longstr errmsg;

  runmode = (strcmp(parms[0], RUNSTR)) ? 1 : 0;   /* '1' if step mode */
  for (i=2;i<ARGSONLINE;i++)
    if (strlen(parms[i]) != 0) {
      strcpy(errmsg, "Error, too many parameters on 'RUN' command.");
      rpnerror(errmsg);
      return;
    }
  if (!strlen(parms[1])) execprog(runmode);   /* Is there a parameter? */
  else {
    flushret();
    if (setpctr(parms[1]) == 0) {
      strcpy(errmsg, "Label not found: ");
      strcat(errmsg, parms[1]);
      rpnerror(errmsg);
      return;
    }
    execprog(runmode);
  }
  redrawstck = drawall = 1;
}

void flushret()
{
  struct programcounter *ptr;

  if (progctr != &basectr) {
    basectr.pctr = progctr->pctr;
    do {
      ptr = progctr;
      progctr = ptr->nextctr;
      free(ptr);                     /* Flush out the return stack */
    } while (progctr != &basectr);
  }
}

void rtnsub()
{
  struct programcounter *ctr;

  if (progctr == &basectr) {   /* Return to toplevel */
    endprog = 1;
    return;
  }
  ctr = progctr;
  progctr = ctr->nextctr;  /* Return to line after gosub */
  progctr->pctr = (progctr->pctr)->nextpmem;
  decpctr();               /* Don't ask, OK? It's a quick patch */
  free(ctr);
}

void setflag(char *label)
{
  struct flags *here, *last;

  here = last = flagroot;
  if (strcmp(label,INDLABEL) == 0) sprintf(label,"%li",(long)irregister);
  while (here != NULL && strcmp(here->flname,label) < 0) {
    last = here;
    here = last->nextflag;
  }
  if (here != NULL && here->flname[0] == label[0] &&
      !strcmp(here->flname,label)) return;
  here = (struct flags *) malloc(sizeof(struct flags));
  if (here == NULL) {
    rpnerror("Memory allocation failure in 'setflag'");
    return;
  }
  if (flagroot == NULL) {
    flagroot = here;
    here->nextflag = NULL;
  } else {
    here->nextflag = last->nextflag;
    last->nextflag = here;
  }
  strcpy(here->flname,label);
  return;
}

void clrflag(char *label)
{
  struct flags *here, *last;

  here = last = flagroot;
  if (strcmp(label,INDLABEL) == 0) sprintf(label,"%li",(long)irregister);
  while (here != NULL && strcmp(here->flname,label) < 0) {
    last = here;
    here = last->nextflag;
  }
  if (here == NULL || here->flname[0] != label[0] ||
      strcmp(here->flname,label) != 0) return;
  if (here == flagroot) {
    if (here->nextflag == NULL) flagroot = NULL;
    else flagroot = here->nextflag;
  } else {
    last->nextflag = here->nextflag;
  }
  free(here);
  return;
}

void chkflag(char *label)
{
  LOCTYP struct flags *here, *last;
  LOCTYP long inum;
  LOCTYP char numeric;
  char *ptr;

  here = last = flagroot;
  numeric = 0;
  if (strcmp(label,INDLABEL) == 0) {
    numeric = 1;
    inum = (long)irregister;
    sprintf(label,"%li",inum);
  } else {
    inum = strtol(label, &ptr, 10);
    if (!(*ptr)) numeric = 1;
  }
  while (here != NULL && strcmp(here->flname,label) < 0) {
    last = here;
    here = last->nextflag;
  }
  if (here != NULL && here->flname[0] == label[0] &&
      strcmp(here->flname,label) == 0) skipnext = 0;
  else skipnext = 1;                                /* Skip if flag clear */
  if (numeric && (inum % 2)) clrflag(label);        /* Clear flag if it was odd */
  return;
}

void xeqzero()
{
  floatval xx;

  drawall = 0;
  popr(&xx);
  if (xx != 0.0) skipnext = 1;
  pushr(&xx);
}

void xeqy()
{
  LOCTYP floatval xx,yy;

  drawall = 0;
  popr(&xx);
  popr(&yy);
  if (xx != yy) skipnext = 1;
  pushr(&yy);
  pushr(&xx);
}

void xneqzero()
{
  floatval xx;

  drawall = 0;
  popr(&xx);
  if (xx == 0.0) skipnext = 1;
  pushr(&xx);
}

void xneqy()
{
  LOCTYP floatval xx,yy;

  drawall = 0;
  popr(&xx);
  popr(&yy);
  if (xx == yy) skipnext = 1;
  pushr(&yy);
  pushr(&xx);
}

void xltzero()
{
  floatval xx;

  drawall = 0;
  popr(&xx);
  if (xx >= 0.0) skipnext = 1;
  pushr(&xx);
}

void xlteqy()
{
  LOCTYP floatval xx,yy;

  drawall = 0;
  popr(&xx);
  popr(&yy);
  if (xx > yy) skipnext = 1;
  pushr(&yy);
  pushr(&xx);
}

void xgtzero()
{
  floatval xx;

  drawall = 0;
  popr(&xx);
  if (xx <= 0.0) skipnext = 1;
  pushr(&xx);
}

void xgty()
{
  LOCTYP floatval xx,yy;

  drawall = 0;
  popr(&xx);
  popr(&yy);
  if (xx <= yy) skipnext = 1;
  pushr(&yy);
  pushr(&xx);
}

void scrnref()
{
  drawall = 1;
  drawrstack();
  memchg = 1;
  drawrmem();
}


void clrrstack()
{
  while (xval != NULL) clxr();
}

void waitasec()
{
  time_t stime;

  stime = time(NULL);
  scrnref();
  while (difftime(time(NULL),stime) < 2) {};
  return;
}

void closeup()
{
#ifndef BUILDCDA
  clrrreg();
  clrrstack();
  clrprog();
#endif
  goto_xy(0,23);
  quitrpn = 1;
}

#ifdef BUILDCDA
void closeup2()
{
  clrrreg();
  clrrstack();
  clrprog();
}
#endif

void applesetup()
{
  Word intstatus;

  if (!(misctls = MTStatus())) MTStartUp();
  intstatus = GetIRQEnable();
  keybdint = intstatus & 0x0080;           /* Are keyboard interrupts up? */
  if (keybdint) IntSource((Word)0x0001);   /* Disable keyboard interrupts */
#ifdef BUILDCDA
  if (!(sanestat = SANEStatus())) SANEStartUp((unsigned int) SANEDP);
#endif
}

void applecloseup()
{
  if (keybdint) IntSource((Word)0x0000);   /* Reenable ints if they were set */
  if (!misctls) MTShutDown();              /* Shut down misctools if necc    */
#ifdef BUILDCDA
  if (!sanestat) SANEShutDown();
#endif
}

unsigned int getkey()
/* Return the keypress, high bit clear, in the low order 8 bits, and
   the key modifier in the high order 8 bits                          */
{
  unsigned char key, mod, strb;

  do {} while ((key = *((char *) KEYBOARD)) < 128);
  key &= 0x7f;
  mod = *((char *) MODLATCH);
  strb = *((char *) CLRSTRB);

  return (mod << 8) + key;
}


#define NUMOPS 99     /* Number of operations supported, listed below */
#define NUMIMMED 83   /* Number of operations available in immediate mode */
#define OPLEN  11     /* Maximum number of keystrokes to define operation */

/* To add new functions, do the following. Create a function which
   accepts arguments as character strings. Create a new field at in the
   opcodes[] array below. Insert it at a natural point in the ordering
   of the table. The table can be reordered without problems. The first
   field should hold a character string of less than 10 characters which
   will appear in the key list. The second field should be a pointer to
   the void function which you've created. The third field should hold the
   number of arguments which that function needs. If the function requires
   more than ARGSONLINE-1 arguments, you should change ARGSONLINE. If the
   function takes a variable number of arguments, use '-1' to indicate
   that this is valid, and null strings will be passed to fill out the
   argument list.                                                        */

struct command {         /* record structure for command table */
  char opname[OPLEN];    /* name of command                    */
  void (*floatfun)();    /* function to call                   */
  int numargs;           /* number of args on the command line, ie. RCL 9 */
  char helpstr[HELPLEN];
};

struct command opcodes[NUMOPS] = {{"+",addr,0,"Add two numbers"},
                                  {"-",subr,0,"Subtract two numbers"},
/* functions numbered from 0 */   {"*",mulr,0,"Multiply two numbers"},
                                  {"/",divr,0,"Divide two numbers"},
                                  {"!",factr,0,"Take the factorial"},
                                  {"1/x",recip,0,"Take the reciprocal"},
                                  {"sqrt",sqrtrx,0,"Take the square root"},
                                  {"x2",sqrr,0,"Take the square"},
                                  {"pow",powrr,0,"Raise 'y' to power 'x'"},
/* function #09 */                {"rdown",rollrdown,0,"Roll stack down"},
                                  {"rup",rollrup,0,"Roll stack up"},
                                  {"x<>y",swapr,0,"Exchange 'x' and 'y'"},
                                  {"abs",absr,0,"Take the absolute value"},
                                  {"pi",pir,0,"Push the value of pi"},
                                  {"ln",lnx,0,"Take the natural log"},
                                  {"ex",expr,0,"Raise as exponent on 'e'"},
                                  {"log",logx,0,"Take the base 10 log"},
                                  {"10x",exp10r,0,"Raise as exponent on 10"},
                                  {"sin",sinx,0,"Take the sine"},
/* function #19 */                {"cos",cosx,0,"Take the cosine"},
                                  {"tan",tanx,0,"Take the tangent"},
                                  {"asin",asinr,0,"Take the inverse sine"},
                                  {"acos",acosr,0,"Take the inverse cosine"},
                                  {"atan",atanr,0,"Take the inverse tangent"},
                                  {"sto",stor,1,"Store in memory label"},
                                  {"rcl",rclr,1,"Recall from memory label"},
                                  {"chs",chsr,0,"Change sign of 'x'"},
                                  {CLRSTR,clxr,0,"Clear 'x' value"},
                                  {"sto+",stoplusr,1,"Add to memory label"},
/* function #29 */                {"sto-",stominr,1,"Subtract from memory label"},
                                  {"sto*",stomulr,1,"Multiply into memory label"},
                                  {"sto/",stodivr,1,"Divide into memory label"},
                                  {"dsp",dispdigs,1,"Digits to display"},
                                  {"fix",fixdisp,0,"Fixed mode display"},
                                  {"sci",scidisp,0,"Scientific mode display"},
                                  {"eng",engdisp,0,"Engineering mode display"},
                                  {"hex",hexdisp,0,"Hexadecimal display"},
                                  {"deg",mdeg,0,"Angles measured in degrees"},
                                  {"rad",mrad,0,"Angles measured in radians"},
/* function #39 */                {"grd",mgrd,0,"Angles measured in grads"},
                                  {"sum+",sigmaplus,0,"Add to statistics regs"},
                                  {"sum-",sigmaminus,0,"Subtract from statistics regs"},
                                  {"avg",xavg,0,"Find average"},
                                  {"sdev",sdevx,0,"Find standard deviation"},
                                  {"lstx",lstrx,0,"Recall LASTX register"},
                                  {"hms+",hmsplus,0,"Add in hours/min/sec form"},
                                  {"p>r",poltorec,0,"Convert polar to rect."},
                                  {"r>d",radtodeg,0,"Convert rad to degrees"},
                                  {"hms>h",hmstoh,0,"Convert hms form to decimal hours"},
/* function #49 */                {"%",percentr,0,"Find 'x' percent of 'y'"},
                                  {"int",intr,0,"Take greatest integer value"},
                                  {"r>p",rectopol,0,"Convert rect. to polar"},
                                  {"d>r",degtorad,0,"Convert degrees to rad."},
                                  {"h>hms",htohms,0,"Convert decimal hours to hms"},
                                  {"%chg",percentchgr,0,"Find 'x' percent change in 'y'"},
                                  {"frac",fracr,0,"Discard whole number part"},
                                  {"x<>i",swapixr,0,"Exchange 'x' and 'i'"},
                                  {"sti",stoir,0,"Store to index 'i'"},
                                  {"rci",rclir,0,"Recall from index 'i'"},
/* function #59 */                {"rnd",round,0,"Round to displayed value"},
                                  {"dsz",dszr,0,"Decrement 'i', skip next instr if zero"},
                                  {"isz",iszr,0,"Increment 'i', skip next instr if zero"},
                                  {"dsz(i)",dszir,0,"'dsz' indirect by 'i'"},
                                  {"isz(i)",iszir,0,"'isz' indirect by 'i'"},
                                  {"sinh",sinhx,0,"Take hyperbolic sine"},
                                  {"cosh",coshx,0,"Take hyperbolic cosine"},
                                  {"tanh",tanhx,0,"Take hyperbolic tangent"},
                                  {"asinh",asinhx,0,"Take inverse hyperbolic sine"},
                                  {"acosh",acoshx,0,"Take inverse hyperbolic cosine"},
/* function #69 */                {"atanh",atanhx,0,"Take inverse hyperbolic tangent"},
                                  {"clreg",clrrreg,0,"Clear memory register"},
                                  {"clrprog",clrprog,0,"Clear program space"},
                                  {"program",progrpn,0,"Enter programming mode"},
                                  {"load",loadprog,0,"Load program file"},
                                  {"save",saveprog,0,"Save program/memory as file"},
                                  {RUNSTR,runprog,-1,"Run program"},
                                  {"step",runprog,-1,"Step through program"},
                                  {GOTOSTR,gotolab,GOTOARGS,"Goto program step"},
                                  {"quit",closeup,0,"Exit RPN"},
/* function #79 */                {"clrstack",clrrstack,0,"Clear stack space"},
                                  {"p<>s",primsec,0,"Exchange stats regs with memory"},
                                  {"sf",setflag,1,"Set named flag"},
                                  {"cf",clrflag,1,"Clear named flag"},
                   /* End of immediate mode functions. In prog mode,
                      the following are also available:               */
                                  {LABELSTR,NULL,1,"Make a label"},
                                  {"gosub",gosublab,1,"Branch to subroutine"},
                                  {"rtn",rtnsub,0,"Return from subroutine"},
                                  {"f?",chkflag,1,"Check status of named flag"},
                                  {"x=0",xeqzero,0,"Skip next step unless x=0"},
                                  {"x=y",xeqy,0,"Skip next step unless x=y"},
/* function #89 */                {"x!=0",xneqzero,0,"Skip next step unless x!=0"},
                                  {"x!=y",xneqy,0,"Skip next step unless x!=y"},
                                  {"x<0",xltzero,0,"Skip next step unless x<0"},
                                  {"x<=y",xlteqy,0,"Skip next step unless x<=y"},
                                  {"x>0",xgtzero,0,"Skip next step unless x>0"},
                                  {"x>y",xgty,0,"Skip next step unless x>y"},
                                  {"update",scrnref,0,"Update screen display"},
                                  {"pause",waitasec,0,"Wait one second"},
                                  {RUNSTOPSTR,NULL,0,"Break statement"},
                                  {USRLBL,usrmode,0,"Return to user mode"}};
                                                    /* usrmode must be
                                                       the last definition */


void goto_xy(int x, int y)
/* This function sends the cursor to row 'y', column 'x' on the screen,
   where the top left is 0,0                                             */
{
  putchar((char) 0x1E);
  putchar((char) (x + 0x20));
  putchar((char) (y + 0x20));
}

void clrscrn()
/* This function clears the screen and homes the cursor */
{
  putchar ((char) 0x0C);
}

void cursoron()
/* This function turns on the cursor. Not supported under the ORCA shell */
{
#ifndef BUILDCDA
  if (!orcashell) putchar ((char) 0x05);
#else
  putchar ((char) 0x05);
#endif
}

void cursoroff()
/* This function hides the cursor */
{
#ifndef BUILDCDA
  if (!orcashell) putchar ((char) 0x06);
#else
  putchar ((char) 0x06);
#endif
}

void clrtoeol()
/* Clear the line to the right of the cursor */
{
  putchar((char) 0x1d);
}

void clrtoeos()
/* Clear to the bottom of the screen */
{
  putchar((char) 0x0b);
}

int mygets(char *instring, int maxchars, int offset)
/* This function gets a string from the keyboard, but it allows for
   the possibility that it is starting part-way into the character
   string, which is already on the screen. Hence, you can backspace
   over to those characters, even if they weren't obtained by this
   subroutine. It does not return the terminating CRET. It returns '1'
   if the input line is completely blanked, zero if CRET was hit.      */
{
#define BACKUP putchar((char)BSPACE)

  LOCTYP int curpos,i,insert;
  LOCTYP char thispress;

  curpos = offset;
  insert = 0;
  do {
    thispress = (char) (getkey() & 0xff);
    if (thispress == CRET) return 0;
    if (instring == NULL) continue;
    if (thispress == TAB) thispress = ' ';    /* Convert tabs to space */
    if (thispress == DELETE && curpos != 0) {
      for (i=0;i<curpos;i++) BACKUP;
      clrtoeol();
      for (i=curpos--;i<=strlen(instring);i++) instring[i-1] = instring[i];
      fputs(instring, stdout);
      for (i=strlen(instring);i>curpos;i--) BACKUP;
      if (strlen(instring) == 0) return 1;
      continue;
    }
    if (thispress == BSPACE && curpos != 0) {
      curpos--;
      BACKUP;
      continue;
    }
    if (thispress == FSPACE && curpos != strlen(instring)) {
      curpos++;
      BACKUP;
      continue;
    }
    if (thispress == INSRT) {
      insert = !insert;
      continue;
    }
    if (iscntrl(thispress)) continue;
    if (curpos >= maxchars-1) continue;
    if (insert) {
      for (i=strlen(instring);i>=curpos;i--) instring[i+1] = instring[i];
      instring[curpos] = thispress;
      clrtoeol();
      fputs(instring+curpos,stdout);
      for (i=strlen(instring);i>curpos+1;i--) BACKUP;
    } else {
      putchar((char)thispress);
      if (instring[curpos] == 0) instring[curpos+1] = 0;
      instring[curpos] = thispress;
    }
    curpos++;
  } while (1);
}
#undef BACKUP

void drawkeys()
/*  This function labels the valid operations. It could draw buttons on
    a graphic screen, or just put labels in the text screen             */
{
#define TOKPERLINE 8   /* Number of tokens displayed on a line */
  int i,rownum,uplim;
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  LOCTYP char line[85];   /* A line to be printed, with space for null termination */
  LOCTYP char blanks[SPACEPERTOK+1];
  LOCTYP char holdstring[2 * (SPACEPERTOK + 1)];
  static int buf1=0, buf2=0;   /* These really are static variables */

  if (howdo == immed && buf1) {
    RestScrn(1);
  } else {
    if (howdo == prog && buf2) {
      RestScrn(2);
    } else {
      rownum = 0;
      cursoroff();
      clrscrn();
      blanks[0] = line[0] = holdstring[0] = 0;
      uplim = (howdo == immed) ? NUMIMMED : NUMOPS;
      for (i=1;i<=SPACEPERTOK;i++) strcat(blanks, " ");
      for (i=0;i<uplim;i++) {
        if (i%TOKPERLINE == 0 && i) {
          goto_xy(0,rownum);
          printf("%79s\n",line);
          line[0] = 0;
          rownum++;
        }
        strcpy(holdstring, opcodes[i].opname);
        strcat(holdstring, blanks);
        strncat(line, holdstring, (int) SPACEPERTOK);
      }
      if (line[0] != 0) {
        for (i=strlen(line)+1;i<=80;i++) strcat(line, " ");
        goto_xy(0,rownum);
        printf("%79s\n",line);
      }
      if (howdo == immed) {
        buf1 = 1;
        SaveScrn(1);
        cursoron();
      } else {
        buf2 = 1;
        SaveScrn(2);
        cursoron();
      }
    }
  }
  if (howdo == immed) {
    goto_xy(8,INPUTLINE - STACKSHOW - 2);
    printf("** STACK **\n");
    goto_xy(60,INPUTLINE - STACKSHOW - 2);
    printf("** MEMORY **\n");
    drawtheta();
  }
}
#undef TOKPERLINE

void drawtheta()
{
  goto_xy(34,INPUTLINE - STACKSHOW - 2);
  printf("THETA= ");
  if (theta == deg) printf("degrees ");
  else if (theta == rad) printf("radians ");
       else printf("gradians");
}

void incpctr()
{
  struct pmem *target;

  target = (progctr->pctr)->nextpmem;
  if (target == &upperpmem) progctr->pctr = basepmem.nextpmem;
  else progctr->pctr = target;
}

void decpctr()
{
  struct pmem *target;

  target = progctr->pctr;
  if (target->lastpmem == NULL) rpnerror("Unexpected invocation of 'decptr'");
  else progctr->pctr = target->lastpmem;
}

void execprog(int runmode)
{
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  struct pmem *pcell;
  LOCTYP struct command commcode;
  LOCTYP floatval xx;
  int cnum;
  LOCTYP char stepping, key, dummy;

  if (basepmem.nextpmem == &upperpmem) {
    usrmode();
    return;
  }
  stepping = runmode;
  for (;;) {
    key = *((char *) KEYBOARD);
    if (stepping || key & 0x80) {
      stepping = 1;
      drawrstack();
      if (memchg) drawrmem();
      redrawstck = drawxy = memchg = sops = 0;
      drawall = 1;
      dummy = *((char *) CLRSTRB);
      goto_xy(0,INPUTLINE);
      clrtoeol();
      writep(progctr->pctr);
      while (!((key = *((char *) KEYBOARD)) & 0x80)) {};
      dummy = *((char *) CLRSTRB);
      if ((key & 0x7F) == ESCAPE) {
        usrmode();
        return;
      }
      if ((key & 0x7F) == CRET) {
        goto_xy(0,INPUTLINE);
        clrtoeol();
        stepping = 0;
      }
    }
    pcell = progctr->pctr;
    incpctr();
    if (pcell->number != HUGE_VAL) {    /* A number was entered */
      pushr(&(pcell->number));
      continue;
    }
    cnum = pcell->commandcode;
    if (cnum == BREAK) {
      usrmode();
      return;
    }
    if (cnum == labelcode) continue;
    if (cnum == ENTERKEY) {     /* pressed ENTER */
      if (xval == NULL) xx = 0.0;
      else {
        popr(&xx);
        pushr(&xx);
      }
      pushr(&xx);
    }
    else {
      commcode = opcodes[pcell->commandcode];
      if (commcode.floatfun != NULL) {
        endprog = skipnext = 0;
        if (commcode.numargs == 0) (*(commcode.floatfun))();
        else (*(commcode.floatfun))((pcell->labels)[0]);    /* Must take 1 arg */
        if (endprog != 0) {
          usrmode();
          return;             /* End program execution */
        }
      }
    }
    if (skipnext != 0) incpctr();
  }
}

void parsep(char *strs[ARGSONLINE], int num)
{
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  size_t len;
  LOCTYP floatval npassed;
  static longstr errmsg;
  LOCTYP char *pos,chkstr[3];
  LOCTYP int cmdreg,errflag,i;
  LOCTYP struct command *opptr;
  LOCTYP struct pmem *saveloc,*freeloc,temploc;

  if (strcmp(strs[0],USRLBL) == 0 || strcmp(strs[0],RUNSTR) == 0) {
    usrmode();
    RestScrn(0);
    return;
  }
  temploc.number = HUGE_VAL;   /* Mark this as not a number unless revoked */
  errflag = 0;
  if (strcmp(strs[0],GOTOSTR) == 0)
    if (num != GOTOARGS+1) {
      errflag = 1;
    } else {
      if (badlabel(strs[1]) == 1) {
        gotolab(strs[1]);
        drawpmem(0);
        return;
      }
    }
  if (num == 0) {  /* Blank line, put in an Enter stroke */
    temploc.commandcode = ENTERKEY;
  } else {
    len = strlen(strs[0]);
    if (len > 2) {
      chkstr[0] = strs[0][0];
      chkstr[1] = toupper(strs[0][1]);
      chkstr[2] = 0;
    }
    else chkstr[0] = 0;
    if (strcmp(chkstr,HEX) == 0) npassed = strtol(strs[0],&pos,16);
    else npassed = strtod(strs[0],&pos);
    if (pos != &strs[0][len]) {
      for (cmdreg=0;cmdreg<=NUMOPS-1;cmdreg++)
        if (strcmp(strs[0],opcodes[cmdreg].opname) == 0) break;
      if (cmdreg == NUMOPS-1) errflag = 1;
      else {
        opptr = &opcodes[cmdreg];
        if (opptr->numargs != num-1) errflag = 1;
        else {
          temploc.commandcode = cmdreg;
          if (!strcmp(strs[0],RUNSTOPSTR)) temploc.commandcode = BREAK;
          for (i=0;i<ARGSONLINE-1;i++) {
            strs[i+1][LABELLEN-1] = 0;     /* Make sure we don't go over */
            strcpy((temploc.labels)[i],strs[i+1]);
          }
        }
      }
    } else {   /* Must be a number */
      if (num != 1) errflag = 1;    /* Numbers don't have arguments */
      else temploc.number = npassed;
    }
  }
  if (errflag) {
    BEEP;
    if (howdo == read) {
      fclose(instream);
      strcpy(errmsg,"Unable to parse input from disk");
      strcat(errmsg,strs[0]);
      rpnerror(errmsg);
      usrmode();
      RestScrn(0);
    }
  } else {
    saveloc = progctr->pctr;
    freeloc = (struct pmem *) malloc(sizeof(struct pmem));   /* Create a new blank entry */
    if (freeloc == NULL) {
      rpnerror("Memory allocation failure in 'parsep'");
      usrmode();
      RestScrn(0);
      return;
    }
    freeloc->nextpmem = saveloc->nextpmem;
    saveloc->nextpmem = freeloc;
    freeloc->lastpmem = saveloc;
    (freeloc->nextpmem)->lastpmem = freeloc;
    freeloc->linenum = saveloc->linenum+1;
    incpnums(freeloc->nextpmem);
    freeloc->commandcode = temploc.commandcode;
    freeloc->number = temploc.number;
    for (i=0;i<num-1;i++)
      strcpy((freeloc->labels)[i], (temploc.labels)[i]);
    incpctr();
    if (!(howdo == read)) drawpmem(1);
  }
}



void parser(char *strs[ARGSONLINE], int num)
{
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  LOCTYP size_t len;
  LOCTYP floatval npassed;
  LOCTYP char *pos;
  LOCTYP int cmdreg,errflag;
  LOCTYP struct command *opptr;
  LOCTYP t_memtags chkstr;

  if (num == 0) {   /* Just <CR> was pressed, so push X into the stack */
    if (xval == NULL) {
      npassed = 0.0;
      pushr(&npassed);
      return;
    }
    popr(&npassed);
    pushr(&npassed);
    pushr(&npassed);
    return;
  }
  errflag = 0;
  len = strlen(strs[0]);
  if (len > 2) {
    chkstr[0] = strs[0][0];
    chkstr[1] = toupper(strs[0][1]);
    chkstr[2] = 0;
  }
  else chkstr[0] = 0;
  if (strcmp(chkstr,HEX) == 0) npassed = strtol(strs[0],&pos,16);
  else npassed = strtod(strs[0],&pos);
  if (pos != &strs[0][len]) {
                     /* parse it as a command */
    cmdreg = 0;
    while (cmdreg<NUMIMMED && (strs[0][0] != opcodes[cmdreg].opname[0] ||
           strcmp(strs[0],opcodes[cmdreg].opname))) cmdreg++;
    if (cmdreg == NUMIMMED) errflag = 1;
    else {
      opptr = &opcodes[cmdreg];
      if (opptr->numargs == -1) {     /* Variable length parameter list */
        (*(opptr->floatfun))(strs);   /* Pass the entire command line as pointers to strings */
        return;
      }
      if (opptr->numargs != num-1 || opptr->floatfun == NULL) errflag = 1;
      else {
        strs[1][LABELLEN-1] = 0;     /* Make sure we don't go over */
        if (num == 2) (*(opptr->floatfun))(strs[1]);
        else (*(opptr->floatfun))();
      }
    }
  }
  else {   /* Must be a number */
    if (num != 1) errflag = 1;    /* Numbers don't have arguments */
    else pushr(&npassed);
  }
  if (errflag) {
    BEEP;
    drawall = 0;
  }
}

void directinput()
{
#define INSIZE 80   /* Maximum length of input string expected */
/*  These variables are static only to trick the compiler. They can safely
    be made 'auto', but not if it is to work as a classic desk accessory    */
  LOCTYP int numparms,i,len,earlyexit,loopback;
  LOCTYP unsigned int press, key, mod;
  LOCTYP char *ptr,bigstring[INSIZE];
  static longstr parmstrs[ARGSONLINE];
  LOCTYP char *parms2[ARGSONLINE], tmp[2];
  LOCTYP char tokens[5] = " \t";    /* Command line separators, space and tab */
  LOCTYP struct pmem *holdmem;

  numparms = 0;
  if (instream == stdin) {    /* Getting from keyboard */
    do {
      loopback = earlyexit = 0;
      goto_xy(0,INPUTLINE);     /* Input line */
      clrtoeol();
      bigstring[0] = 0;
      press = getkey();
      key = press & 0xff;
      mod = (press & 0xff00) >> 8;
      if (mod & 0x10) {          /* Keypad key          */
        if (strchr("/*+-",key) != NULL) {
          bigstring[0] = key;
          bigstring[1] = 0;
          earlyexit = 1;
        }
        if (key == CTRLX) {      /* CLEAR key on keypad */
          strcpy(bigstring, CLRSTR);
          earlyexit = 1;
        }
      }
      if (key == REFRESH) {      /* REFRESH was pressed */
        drawkeys();
        if (howdo == prog) {
          drawpmem(0);
        } else {
          memchg = 1;
          redrawstck = 1;
        }
        return;
      }
      if (key == EXITKEY) {
       if (howdo == prog) {
         strcpy(bigstring, USRLBL);
         earlyexit = 1;
       } else {
          closeup();   /* EXITKEY was pressed */
          return;
        }
      }
      if (mod & 0x02 && key == HELPKEY) {
        helpscrn();
        return;
      }
      if (mod & 0x80) {  /* Check <OA> label/run shorthand */
        tmp[0] = key;
        tmp[1] = 0;
        if (isprint(key) && !badlabel(tmp)) {
          if (howdo == prog) strcpy(bigstring, LABELSTR);
          else strcpy(bigstring, RUNSTR);
          strcat(bigstring, " ");
          strcat(bigstring, tmp);
          earlyexit = 1;
        }
      }
      if (howdo == prog && (mod & 0x80))   /* Check <OA>- keys */
        switch (key) {
          case DELETE:
            holdmem = progctr->pctr;
            if (holdmem == &basepmem) {
              BEEP;
              return;
            }
            decpnums(progctr->pctr);
            decpctr();
            (holdmem->lastpmem)->nextpmem = holdmem->nextpmem;
            (holdmem->nextpmem)->lastpmem = holdmem->lastpmem;
            free(holdmem);
            drawpmem(3);
            return;
            break;
          case UPARROW:
            if (progctr->pctr == &basepmem) {
              BEEP;
              return;
            }
            decpctr();
            drawpmem(4);
            return;
            break;
          case DOWNARROW:
            if (((progctr->pctr)->nextpmem)->nextpmem == NULL) {
              BEEP;
              return;
            }
            incpctr();
            drawpmem(2);
            return;
            break;
        }
      if (!earlyexit)
        if (isprint(key)) {
          bigstring[0] = key;
          bigstring[1] = 0;
          putchar(key);
          loopback = mygets(bigstring,INSIZE,1);
        } else {
          if (key == CRET) bigstring[0] = 0;
          else loopback = 1;
        }
    } while (loopback);
    len = strlen(bigstring);
    ptr = strtok(bigstring, tokens);
    while (ptr != NULL && numparms < ARGSONLINE) {
      strcpy(parmstrs[numparms++], ptr);
      ptr = strtok(NULL,NULL);
    }
  } else {
    if (fgets(bigstring,INSIZE,instream) == NULL)
      bigstring[0] = 0;
    else {
      if (COMMENTS) bigstring[COMMENTS] = 0;
      len = strlen(bigstring);
      bigstring[len-1] = 0;              /* Replace the newline with null */
      ptr = strtok(bigstring, tokens);
      while (ptr != NULL && numparms < ARGSONLINE) {
        strcpy(parmstrs[numparms++], ptr);
        ptr = strtok(NULL,NULL);
      }
    }
    if (feof(instream)) {
      usrmode();      /* end of file reached */
      instream = stdin;
      return;
    }
  }
  for (i=numparms;i<ARGSONLINE;i++) parmstrs[i][0] = 0;
  for (i=0;i<ARGSONLINE;i++) parms2[i] = &(parmstrs[i][0]);
  (*procstream)(parms2,numparms);
}

void helpscrn()
{
  int i;

  SaveScrn(3);
  clrscrn();
  for (i=0;i<(howdo == prog ? NUMOPS : NUMIMMED);i++) {
    printf("%s     %s\n", opcodes[i].opname, opcodes[i].helpstr);
    if (!((i + 1) % HELPLINES)) {
      printf("\n--- More ---\n");
      getkey();
      clrscrn();
    }
  }
  RestScrn(3);
}

void writer(floatval numtoshow)
{
  LOCTYP char dispstr[FIELDWIDTH+2],holdstr[FIELDWIDTH+2];
  LOCTYP char blanks[FIELDWIDTH+1] = "                              ";
                                         /* FIELDWIDTH of them */
  static longstr toshow;
  LOCTYP int epos,i,expon,expon2,decptr;
  LOCTYP floatval room;

  if (FLTABS(numtoshow) == HUGE_VAL) {     /* Print error message */
    strcpy(dispstr,"<<< ERROR >>>");
    epos = strlen(dispstr);
    strncat(dispstr,blanks,FIELDWIDTH+1-epos);
    puts(dispstr);
    return;
  }
  if (outstream != stdout) {
    fprintf(outstream, "%.*le", MAXDIGS-1, numtoshow);
    return;
  }
  if (numtoshow == 0.0) room = 0.0;
  else room = log10(FLTABS(numtoshow));
  if (disp == sci || (disp == fix && (room >= MAXDIGS || room < -digits))
                  || howdo == prog) {
                        /* print a stack element in scientific notation */
    sprintf(holdstr,"%+.*le",digits,numtoshow);
    epos = strpos(holdstr, 'e')+1;   /* Find the split between mantissa and exp */
    strncpy(dispstr,holdstr,epos-1); /* Put the mantissa in 'dispstr' */
    dispstr[epos-1] = 0;     /* Null terminate it */
    strncat(dispstr,blanks,MAXDIGS+4-epos);  /* Pad with blanks */
    expon = atoi(&(holdstr[epos]));
    sprintf(holdstr,"%0 .4d",expon);
    strcat(dispstr, holdstr);
  }
  else {
    if (disp == fix) {
      expon = 0;
      sprintf(toshow,"%+.*Lf",digits,numtoshow);
      strncpy(dispstr,toshow,MAXDIGS+2);
      dispstr[MAXDIGS+2] = 0;
      if (expon == 1) strcat(dispstr,"0");
      epos = strlen(dispstr);
      strncat(dispstr,blanks,FIELDWIDTH+1-epos);
    }
    else {
      if (disp == eng) {    /* engineering notation */
        sprintf(holdstr,"%+.*le",digits,numtoshow);
        epos = strpos(holdstr, 'e')+1;   /* Find the split between mantissa and exp */
        strncpy(dispstr,holdstr,epos-1); /* Put the mantissa in 'dispstr' */
        dispstr[epos-1] = 0;     /* Null terminate it */
        strncat(dispstr,blanks,MAXDIGS+4-epos);
        expon = expon2 = atoi(&holdstr[epos]);
        decptr = strpos(dispstr, '.');
        for (i=1;i<=expon%3;i++) {    /* Shift the decimal point and exponent */
          dispstr[decptr] = dispstr[decptr+1];
          dispstr[decptr+1] = '.';
          decptr++;
          expon2--;
        }
        if (holdstr[epos] == '-') strcat(dispstr,"-");
        else strcat(dispstr," ");
        sprintf(holdstr,"%04i",abs(expon2));
        strcat(dispstr,holdstr);
      }
      else {       /* Must be hex notation */
        sprintf(dispstr,"%+#lx",(unsigned long)numtoshow);
        epos = strlen(dispstr);
        strncat(dispstr,blanks,FIELDWIDTH-epos);
      }
    }
  }
  fputs(dispstr, stdout);
}

void drawrmem()
{
  LOCTYP int level;
  struct rmem *thisptr, *lastptr;

  cursoroff();
  thisptr = memrroot;
  while (thisptr != NULL && thisptr->val == 0.0) {   /* Kill all zero entries */
    lastptr = thisptr;
    thisptr = thisptr->nextmem;
    free(lastptr);
  }
  memrroot = thisptr;
  if (memrroot != NULL) {
    lastptr = thisptr;
    thisptr = thisptr->nextmem;
    while (thisptr != NULL)
      if (thisptr->val == 0.0) {
        lastptr->nextmem = thisptr->nextmem;
        free(thisptr);
        thisptr = lastptr->nextmem;
      } else {
        lastptr = thisptr;
        thisptr = thisptr->nextmem;
      }
  }                                      /* Killing over */
  thisptr = memrroot;
  for (level=1;level<=STACKSHOW;level++) {
    if (thisptr != NULL) {
      goto_xy(RIGHTCOL-LABELLEN-2,INPUTLINE-level);
      printf("%*s=",LABELLEN,thisptr->memtag);
      goto_xy(RIGHTCOL,INPUTLINE-level);
      writer(thisptr->val);
      thisptr = thisptr->nextmem;
    }
    else {
      goto_xy(RIGHTCOL-LABELLEN-2,INPUTLINE-level);
      printf("%*s",FIELDWIDTH+LABELLEN+2,"");
    }
  }
  cursoron();
}


void drawpmem(int mode)
/*  This subroutine draws or updates the program memory display on the
    screen. The modes available are:  0   redraw everything
               insert entry           1   scroll up left column
               step forward           2   scroll up both columns
               delete entry           3   scroll down left column
               step backward          4   scroll down both columns      */
{
  LOCTYP struct pmem *memloc;
  LOCTYP int i;

  memloc = progctr->pctr;
  switch (mode) {
    case 0:
      Blank(23-PROGSHOW,0,22,79);   /* Blank the whole area */
      for (i=0;i<PROGSHOW;i++) {
        if (memloc == NULL) break;
        goto_xy(0,22-i);
        writep(memloc);
        memloc = memloc->lastpmem;
      }
      memloc = (basectr.pctr)->nextpmem;
      for (i=1;i<=PROGSHOW;i++) {
        if (memloc == NULL) break;
        goto_xy(40,22-PROGSHOW+i);
        writep(memloc);
        memloc = memloc->nextpmem;
      }
      return;
      break;
    case 1:
      Scrollup(23-PROGSHOW,0,22,39);
      goto_xy(0,22);
      writep(memloc);
      Scrolldown(23-PROGSHOW,40+NUMWDTH,22,79);
      Scrollup(23-PROGSHOW,40,22,79);
      break;
    case 2:
      Scrollup(23-PROGSHOW,0,22,79);
      goto_xy(0,22);
      writep(memloc);
      break;
    case 3:
      Scrolldown(23-PROGSHOW,0,22,39);
      Scrollup(23-PROGSHOW,40+NUMWDTH,22,79);
      Scrolldown(23-PROGSHOW,40,22,79);
      if (memloc->nextpmem != NULL) {
       goto_xy(40, 23-PROGSHOW);
       writep(memloc->nextpmem);
      }
      for (i=1;i<PROGSHOW;i++) {
        memloc = memloc->lastpmem;
        if (memloc == NULL) break;
      }
      if (memloc != NULL) {
        goto_xy(0,23-PROGSHOW);
        writep(memloc);
      }
      memloc = progctr->pctr;
      for (i=1;i<=PROGSHOW;i++) {
       memloc = memloc->nextpmem;
       if (memloc == &upperpmem) {
         Blank(23-PROGSHOW+i,40,22,79);
         break;
       }
      }
      return;
      break;
    case 4:
      Scrolldown(23-PROGSHOW,0,22,79);
      memloc = memloc->nextpmem;
      if (memloc != NULL) {
        goto_xy(40,23-PROGSHOW);
        writep(memloc);
      }
      memloc = basectr.pctr;
      for (i=1;i<PROGSHOW;i++) {
        memloc = memloc->lastpmem;
        if (memloc == NULL) break;
      }
      if (memloc != NULL) {
        goto_xy(0,23-PROGSHOW);
        writep(memloc);
      }
      return;
      break;
  }
  memloc = progctr->pctr;
  for (i=PROGSHOW;i>=1;i--) {
    memloc = memloc->nextpmem;
    if (memloc == &upperpmem) {
      goto_xy(40,23-i);
      writep(memloc);
      return;
    }
    if (memloc == NULL) return;
  }
  goto_xy(40,22);
  writep(memloc);             /* Put the lower right entry on screen */
  return;
}

void writep(struct pmem *memloc)
/*  This subroutine draws the program memory at 'memloc' to the current
    screen location                                                     */
{
  LOCTYP int i, holddigs;
  LOCTYP enum displaytypes holddsp;

  if (outstream == stdout) printf("%*lu:  ", NUMWDTH, memloc->linenum);
  if (memloc->commandcode == BREAK) {
    if (outstream != stdout) fprintf(outstream, RUNSTOPSTR "\n");
    else printf(BREAKSTR);
    return;
  }
  if (memloc->commandcode == ENTERKEY) {
    if (outstream != stdout) fprintf(outstream, "\n");
    else printf(ENTERSTR);
    return;
  }
  if (memloc->number == HUGE_VAL) {   /* It's a command code */
    fprintf(outstream,"%-*s",SPACEPERTOK+1,opcodes[memloc->commandcode].opname);
    for (i=1; i<=opcodes[memloc->commandcode].numargs; i++)
      fprintf(outstream,"%-*s", LABELLEN+1, memloc->labels[i-1]);
    return;
  }
  /* It's a number */
  if (howdo == write) {
    fprintf(outstream, "%.*le", MAXDIGS-1, memloc->number);
  } else {
    holddsp = disp;
    holddigs = digits;
    disp = sci;
    digits = MAXDIGS-1;
    writer(memloc->number);
    disp = holddsp;
    digits = holddigs;
  }
  return;
}


void drawrstack()
{
  LOCTYP int level,i,finishearly;
  struct rstack *ptr;

  cursoroff();
  finishearly = 0;
  ptr = xval;
  if (ptr == NULL) {   /* Empty stack, write 0 */
    goto_xy(0,INPUTLINE-1);
    printf("%s\n",novalstr);
    Blank(INPUTLINE-STACKSHOW,0,INPUTLINE-2,FIELDWIDTH);
    cursoron();
    return;
  }
  if (!drawall) {
    goto_xy(0,INPUTLINE-1);
    writer(ptr->val);
    if (drawxy) {
      goto_xy(0,INPUTLINE-2);
      writer((ptr->nextval)->val);
    }
    cursoron();
    return;
  }
  if (redrawstck) {
    Blank(INPUTLINE-STACKSHOW,0,INPUTLINE-2,FIELDWIDTH);
    for (level=1;level<=STACKSHOW;level++) {
      if (ptr != NULL) {
        goto_xy(0,INPUTLINE-level);
        writer(ptr->val);
        ptr = ptr->nextval;
      }
      else {
        Blank(INPUTLINE-STACKSHOW,0,INPUTLINE-level,FIELDWIDTH);
        break;
      }
    }
  } else {
    if (sops >= 0)
      for (level=1;level<=sops;level++) {
       ptr = xval;
        if (ptr->nextval != NULL)
          Scrollup(INPUTLINE-STACKSHOW,0,INPUTLINE-1,FIELDWIDTH);
        for (i=1;i<sops-level;i++) ptr = ptr->nextval;
        goto_xy(0,INPUTLINE-1);
        writer(ptr->val);
      }
    else {
      for (level=-1;level>=sops;level--)
        Scrolldown(INPUTLINE-STACKSHOW,0,INPUTLINE-1,FIELDWIDTH);
      goto_xy(0,INPUTLINE-1);
      writer(xval->val);
      ptr = xval;
      for (i=1;i<=STACKSHOW;i++) {
        if (i>STACKSHOW+sops) {
          goto_xy(0,INPUTLINE-i);
          writer(ptr->val);
        }
        if ((ptr = ptr->nextval) == NULL) break;
      }
    }
  }
  cursoron();
}

void openscrn()
{
  clrscrn();
  printf("      RPN %s  -   A Scientific Calculator in ",VERSIONLABEL);
  printf("Reverse Polish Notation\n\n\n");
  printf("   Copyright (c) 1992 by Christopher Neufeld\n\n");
  printf("   The executable for this program contains linked runtime libraries\n");
  printf("       copyrighted by Byte Works Inc.\n\n\n");
  printf("   This program was inspired by my HP-67 calculator\n\n\n");
  printf("   Press <RETURN> to continue.   ");
  mygets(NULL, 0, 0);
  cursoroff();
}

void main()
{
  LOCTYP floatval xx;

  applesetup();
#ifndef BUILDCDA
  if ((shellid() != NULL) && !strcmp(shellid(), "BYTEWRKS")) orcashell = 1;
#endif
  xx = -1.0;
  pival = acos(xx);
  for (labelcode=NUMIMMED;labelcode<NUMOPS;labelcode++)
    if (!strcmp(LABELSTR, opcodes[labelcode].opname)) break;
  instream = stdin;
  outstream = stdout;
  procstream = parser;
  quitrpn = 0;
  howdo = immed;
  openscrn();
  drawkeys();
  drawrmem();
  redrawstck = drawall = 1;
  while (!quitrpn) {
    if (howdo == immed) drawrstack();
    skipnext = memchg = drawxy = sops = redrawstck = 0;
    drawall = 1;
    directinput();   /* Use the processor, keyboard input or program */
    if (memchg && howdo == immed) drawrmem();
  }
  clrtoeos();
  applecloseup();
}

