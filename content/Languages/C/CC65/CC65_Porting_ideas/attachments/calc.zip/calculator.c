/***********************************************************/
/*  CALCULATOR PROGRAM DEVELOPED BY A.KEERTHIVASAN         */
/*    B.Tech INDUSTRIAL BIOTECHNOLOGY                      */
/*          ANNA UNIVERSITY                                */
/*      keerthivasan@yahoo.com                             */
/***********************************************************/

#include<stdio.h>
#include<conio.h>
#include<math.h>

long int a,b,fac;int choice,option,n,r;
float result,f;
long g,res;
int op;

main()
{
    clrscr();
    printf("\t\t\t\tCALCULATOR\n\n\n\t\tprogram developed by A.keerthivasan\n");
    printf("OPERATIONS:\nenter a choice[1-10]\n");
    printf("1.ADDITION\n");
    printf("2.SUBTRACTION\n");
    printf("3.MULTIPLICATION\n");
    printf("4.DIVISION\n");
    printf("5.TRIGONOMETRIC\n");
    printf("6.LOGARITHMIC\n");
    printf("7.SQUARE&SQUARE ROOTS\n");
    printf("8.CUBES\n");
    printf("9.FACTORIAL\n");
    printf("10.EXIT\n");
    printf("Enter a choice :");scanf("%d",&choice);

    switch(choice)
    {
	case 1:
	  add();
	  break;
	case 2:
	  sub();
	  break;
	case 3:
	  mul();
	  break;
	case 4:
	  div();
	  break;
	case 5:
	  trig();
	  break;
	case 6:
	  loga();
	  break;
	case 7:
	  square();
	  break;
	case 8:
	  cube();
	  break;
	case 9:
	  fact();
	  break;
	case 10:
	  exit();
	  break;
	default:
	  printf("Please enter a valid choice");
	  break;
    }
   getch();
   check();
}

getelement()
{
      printf("\n\n\n\n\n\n\n\n\n\t\t\tEnter number 1:");scanf("%ld",&a);
      printf("\t\t\tEnter number 2:");scanf("%ld",&b);
}

showresult()
{
    clrscr();
    printf("\n\n\n\n\n\n\n\n\n\t\t\t\aThe result is:%f\n",result);
    getch();

}
check()
{
    clrscr();
    printf("\n\n\n\n\n\n\n\n\n\n\t\t\tWant to do another operation?\n\t\t\tpress 1 for yes any key for no\n");
    scanf("%d",&op);
    if(op==1)
    {
    main();
    }
    else
    {
    return;
    }
    return;
}
           /* math function programs */
add()
{
    clrscr();
    getelement();
    result=a+b;
    showresult();
    return;
}
sub()
{
    clrscr();
    getelement();
    result=a-b;
    showresult();
    return;
}
mul()
{
    clrscr();
    getelement();
    result=a*b;
    showresult();
    return;
}
div()
{
    clrscr();
    getelement();
    g=a/b;
    printf("\n\n\n\n\n\n\n\n\n\t\t\t\aThe result is:%lf",g);
    return;
}
trig()
{
    clrscr();
    printf("Enter the angle in degrees\n");scanf("%f",&f);
    g=(6.2856/360)*f;
    printf("What trigonometric operation do you want to perform?\n");
    printf("1.SINE\n2.COS\n3.TAN\n4.COSEC\n5.SEC\n6.COT\n7.EXIT\n");
    printf("Enter an option[1-7]");scanf("%d",&option);
    switch(option)
    {
    case 1:
	clrscr();
	res=sin(g);
	printf("\n\n\n\n\n\n\n\n\n\t\t\tANSWER:%lf\n",res);
	break;
    case 2:
	clrscr();
	res=cos(g);
	printf("\n\n\n\n\n\n\n\n\n\t\t\tANSWER:%lf\n",res);
	break;
    case 3:
	res=tan(g);
	clrscr();
	printf("\n\n\n\n\n\n\n\n\n\t\t\tANSWER:%lf\n",res);
	break;
    case 4:
	res=1/sin(g);
	clrscr();
	printf("\n\n\n\n\n\n\n\n\n\t\t\tANSWER:%lf\n",res);
	break;
    case 5:
	res=1/cos(g);
	clrscr();
	printf("\n\n\n\n\n\n\n\n\n\t\t\tANSWER:%lf\n",res);
	break;
    case 6:
	res=1/tan(g);
	clrscr();
	printf("\n\n\n\n\n\n\n\n\n\t\t\tANSWER:%lf\n",res);
	break;
    default:
	clrscr();
	printf("\n\n\n\n\n\n\n\n\n\t\t\tEnter a valid choice\n");
	break;
    }
}
loga()
{
    float x,y;clrscr();
    printf("What log function do you want to perform?\n");
    printf("1.LOG\n2.NATURAL LOG (ln)\n3.ePOWx\n4.xPOWy\npress any other number to exit");
    scanf("%d",&option);
    switch(option)
    {
	case 1:
	printf("Enter a:\n");scanf("%ld",&a);
	res=log10(a);
	printf("ANSWER:%lf\n",res);
	break;
	case 2:
	printf("Enter a:\n");scanf("%ld",&a);
	res=log(a);
	printf("ANSWER:%lf\n",res);
	break;
	case 3:
	printf("Enter a:\n");scanf("%ld",&a);
	res=exp(a);
	printf("ANSWER:%lf\n",res);
	break;
	case 4:
	printf("Enter x:\n");scanf("%f",&x);
	printf("Enter y:\n");scanf("%f",&y);
	res=pow(x,y);
	printf("ANSWER:%lf\n",res);
	break;
	default:
	break;
    }
}
square()
{
    clrscr();
    printf("What option do you want to perform?\n");
    printf("1.SQUARE\n2.SQUAREROOT\n");
    printf("Press any other key to exit");scanf("%d",&option);
    switch(option)
    {
	case 1:
	printf("\n\n\n\n\n\n\t\t\tEnter the number\n");scanf("%ld",&a);
	result=a*a;
	showresult();
	break;
	case 2:
	printf("\n\n\n\n\n\n\t\t\tEnter the number\n");scanf("%ld",&a);
	result=sqrt(a);
	showresult();
	break;
	default:
	break;
    }
    return;
}
cube()
{
    clrscr();
    printf("Enter the number\n");scanf("%ld",&a);
    result=a*a*a;
    showresult();
    return;
}
fact()
{
    int i,j;long int k;
    clrscr();
    printf("OPERATION:\n1.FACTORIAL\n2.PERMUTATION(nPr)\n3.COMBINATION(nCr)\n");
    printf("What operation do you want to perform?\nEnter a choice[1-3]:");
    scanf("%d",&option);printf("Enter the number:");scanf("%d",&n);
    switch(option)
    {
    case 1:
	facto(n);
	printf("The factorial is:%ld",fac);
	break;
    case 2:
	printf("Enter r value:\n");scanf("%d",&r);
	k=facto(n)/facto(r);
	printf("The nPr value is:%ld",k);
	break;
    case 3:
	printf("Enter r value:\n");scanf("%d",&r);
	k=facto(n)/(facto(n-r)*facto(r));
	printf("The nCr value is:%ld",k);
	break;
    default:
	break;
    }
}

int facto(int a)
{
    int i,j;
    fac=1;
    for(i=a;i>=1;i--)
	{
	    fac=(fac*i);
	}
    return fac;
}
