# include <stdio.h>
# include <conio.h>
# define MAXOP 20        /* MAX SIZE OF OPERAND OPERATOR */
# define NUMBER '0'      /* SIGNAL NUMBER FOUND */
# define TOOBIG '9'      /* SIGNAL STRING IS TOO BIG */

 # define MAXVAL 100     /* MAX DEPTH OF VALUE STACK */
 int sp = 0 ;            /* STACK POINTER */
 int val[MAXVAL] ;    /* VALUES STACK */

 int push(f)           /* PUSH f ON TO VALUE STACK */
 int f ;
 {
   if (sp < MAXVAL )
     return (val[sp++] = f) ;
   else {
     printf(" error : stack full \n ") ;
     clear() ;
     return (0) ;
   }
 }

 int pop()             /* POP TOP VALUE FROM STACK */
 {
   if (sp > 0)
     return(val[--sp]) ;
   else {
     printf("error : stack empty \n") ;
     clear() ;
   return (0) ;
   }
 }

 clear ()                 /* CLEAR STACK */
 {
   sp = 0;
   return 0 ;
 }

 getop(s,lim)             /* GET NEXT OPERATOR OR OPERAND */
 char s[] ;
 int lim ;
 {
   int i , c ;
   while (( c = getch()) == ' ' || c == '\t' || c == '\n' )
     ;
   if (c != '.' && (c < '0' || c > '9'))
     return(c) ;
   s[0] = c ;
   for (i = 1; (c = getchar()) >= '0' && c <= '9' ; i++)
     if (i < lim)
       s[i] = c ;
   if (c == '.') {        /* COLLECT FRACTION */
     if (i < lim)
       s[i] = c ;
     for (i++ ; (c = getchar()) <= '0' && c <= '9' ; i++)
       if (i < lim)
	 s[i] = c ;
   }
   if (i < lim) {         /* NUMBAR IS OK */
     ungetch(c) ;
     s[i] = '0' ;
     return (NUMBER) ;
   }
     else {                 /* ITS TOO BIG SKIP REST OF LINE */
       while (c != '\n' && c != EOF)
	 c = getchar() ;
       s[lim-1] = '0' ;
       return (TOOBIG) ;
     }
 }

 # define BUFSIZE 100
 char buf[BUFSIZE] ;        /* BUFFER FOR ungetch */
 int bufp = 0 ;             /* NEXT FREE POSITION IN BUF */
 getch()                    /* GET A POSSIBLY PUSHED BACK CHARACTER */
 {
   return ((bufp > 0) ? buf[--bufp] : getchar()) ;
 }

 ungetch(c)
 int c ;
 {
   if (bufp > BUFSIZE)
     printf("ungetch: too many characters \n") ;
   else
     buf[bufp++] = c ;
   return 0 ;
 }

void main()
{
  int type ;
  char s[MAXOP] ;
  int op2, atoi();

  printf("\n\nRPN Calculator \n") ;
  printf("-------------- \n\n\n") ;
  printf("<num> + - * \\ = c  \n") ;

  while (( type = getop(s,MAXOP)) != EOF)
    switch (type) {
      case NUMBER :
	push(atoi(s)) ;
	break ;

      case '+' :
	push(pop() + pop()) ;
	break ;

      case '*' :
	push(pop() * pop()) ;
	break ;

      case '-' :
	op2 = pop() ;
	push(pop() - op2) ;
	break;

      case '/' :
	op2 = pop();
	if (op2 != 0)
	  push(pop() / op2) ;
	else
	  printf("zero divisor popped \n") ;
	break;

      case '=' :
	printf("\t %f \n",push(pop())) ;
	break ;

      case 'c' :
	clear() ;
	  break ;

      case TOOBIG :
	printf("%20s ... is too long \n",s) ;
	break ;

      default :
	printf("unknown command %c \n", type) ;
	break ;

    }
 }

















