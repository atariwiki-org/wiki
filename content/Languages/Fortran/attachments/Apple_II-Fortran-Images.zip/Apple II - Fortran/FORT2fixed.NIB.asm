Begin3
Title:          FORT2fixed.nib
Author:         Unknown
Version:        May 22, 2002
Entered-date:   June 2, 2002
Description:    "FORT2.nib" without extraneous data
Keywords:       Fortran
Uploader:       WilliK@verizon.net (Willi Kusche)
Primary-site:   ftp.asimov.net/pub/apple_II/unsorted
Platform:       Apple ][+
End
