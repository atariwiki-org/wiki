typedef struct  m_pos_struct  {
	int  moves[200];
	int  nmoves;
	int  player_to_move;
	int  pits[14];
} m_pos_t;


typedef m_pos_t  ab_position_t;

typedef int  ab_score_t;

#define  AB_WIN_SCORE  (48*1024+1024)  /* Just a huge value. */

#define  AB_MAX_MOVES  6

typedef struct  ab_move_struct  {
	int  pit;
	int  score;
} ab_move_t;

typedef struct  ab_storage_struct  {
	int  old_tomove;
	int  oldpits[14];
} ab_storage_t;

#define  AB_MOVE_VAL(move)  ((move).score)
#define  AB_PLAYER_TO_MOVE(pos)  ((pos).player_to_move)

extern int  ab_generate_moves(ab_position_t *pos, ab_move_t *moves);
extern ab_score_t  ab_do_move(ab_position_t *pos, ab_move_t *move,
															ab_storage_t *storage);
extern void  ab_undo_move(ab_position_t *pos, ab_storage_t *storage);
extern int  ab_move_cmp(ab_move_t *mv1, ab_move_t *mv2);

extern ab_move_t  ab_search(ab_position_t *pos, int depth);
