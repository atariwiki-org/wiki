; $Id: strtab.asm , cstrotm $
;
;  RAF Commander - A free File Manager for Atari 8bit
;  Copyright (C) 1999-2000 Regionalgruppe Atari Frankfurt / RAF
;
;  This program is free software; you can redistribute it and/or
;  modify it under the terms of the GNU General Public License
;  as published by the Free Software Foundation; either version 2
;  of the License, or (at your option) any later version.
; 
;  This program is distributed in the hope that it will be useful,
;  but WITHOUT ANY WARRANTY; without even the implied warranty of
;  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;  GNU General Public License for more details.
;
;  You should have received a copy of the GNU General Public License
;  along with this program; if not, write to the Free Software
;  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
;  or visit http://www.gnu.org

; Fixed Srings

STRFIX
    QSTR .BYTE  "ANYL"       ; String  for  Question  Dialog.  
                             ; 1st letter for "(A)bort", 
                             ; 2nd letter for "(N)o",
                             ; 3rd letter for "(Y)es",
                             ; 4th letter for "A(L)l"

; String table for relocating text
; table of pointers to text strings
; String should never accessed direct in this
; program, but through pointers to the text

STRTAB
    P_0RAFM .WORD RAF0

    P_0DSKM .WORD DSK0
    P_1DSKM .WORD DSK1

    P_0FREM .WORD FRES
    P_1FREM .WORD FRES
    P_SFREM .WORD FRES

    P_0DFIL .WORD DFI0
    P_1DFIL .WORD DFI1
    P_DRVS  .WORD DRVS
    P_DSTR  .WORD DSTR
    P_CSTR  .WORD CSTR

    P_LOC0  .WORD LOC0
    P_COP0  .WORD COP0
    P_MOV0  .WORD MOV0
    P_DEL0  .WORD DEL0
    P_LOA0  .WORD LOA0
    P_PROC  .WORD 0         ; Pointer to Process Text
    P_ASTR  .WORD ASTR

; text srings for screen output
; Hi-Bit set is EOL marker
; (done by .CBYTE dircetive

STRMEM

    RAF0 .CBYTE "RAF Disk Commander 2000"

    LOC0 .CBYTE "(Un)Locking"
    COP0 .CBYTE "Copy"
    MOV0 .CBYTE "Move"
    DEL0 .CBYTE "Delete"
    LOA0 .CBYTE "Loading"
    
    DRVS .CBYTE "12xxxxx8x"
    ASTR .CBYTE "(Y)es (N)o (A)bort A(l)l"

    DSK0 .CBYTE "[Dx:]"
    DSK1 .CBYTE " D       "

    FRES .CBYTE "free:"
    CURC .BYTE 30                   ; Marker Char
 
    DFI
    DFI0 .BYTE "D1:*.*         "    ; FILTER LEFT
    DFI1 .BYTE "D1:*.*         "    ; FILTER RIGHT
    DSTR .CBYTE "D1:             "    ; String for Disk Operations
    CSTR .CBYTE "D1:             "    ; String for Copy/Move Operations


