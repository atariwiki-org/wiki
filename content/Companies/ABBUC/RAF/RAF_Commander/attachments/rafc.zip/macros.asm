; $Id: macros.asm , cstrotm $
;
;  RAF Commander - A free File Manager for Atari 8bit
;  Copyright (C) 1999-2000 Regionalgruppe Atari Frankfurt / RAF
;
;  This program is free software; you can redistribute it and/or
;  modify it under the terms of the GNU General Public License
;  as published by the Free Software Foundation; either version 2
;  of the License, or (at your option) any later version.
; 
;  This program is distributed in the hope that it will be useful,
;  but WITHOUT ANY WARRANTY; without even the implied warranty of
;  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;  GNU General Public License for more details.
;
;  You should have received a copy of the GNU General Public License
;  along with this program; if not, write to the Free Software
;  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
;  or visit http://www.gnu.org

; Macros

; >>>>>> MACROS <<<<<<

.MACRO M_FRAME
    LDA #%2
    STA ROWCRS
    LDA #%1
    STA COLCRS
    LDA #%3
    STA N
    LDA #%4
    STA N+1
    JSR XFRAME
.ENDM

.MACRO M_CHOUT
    LDA #%1
    JSR OUTCH
.ENDM

.MACRO M_POS
    LDA #%2
    STA ROWCRS
    LDA #%1
    STA COLCRS
.ENDM

.MACRO M_PRINT
    INX
    INX
    LDA # <%1
    STA 0,X
    LDA # >%1
    STA 1,X
    JSR XSTROUT
    DEX
    DEX
.ENDM

