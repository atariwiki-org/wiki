; $Id: vartab.asm , cstrotm $
;
;  RAF Commander - A free File Manager for Atari 8bit
;  Copyright (C) 1999-2000 Regionalgruppe Atari Frankfurt / RAF
;
;  This program is free software; you can redistribute it and/or
;  modify it under the terms of the GNU General Public License
;  as published by the Free Software Foundation; either version 2
;  of the License, or (at your option) any later version.
; 
;  This program is distributed in the hope that it will be useful,
;  but WITHOUT ANY WARRANTY; without even the implied warranty of
;  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;  GNU General Public License for more details.
;
;  You should have received a copy of the GNU General Public License
;  along with this program; if not, write to the Free Software
;  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
;  or visit http://www.gnu.org

; Variable Memory

VARMEM

    XPS0  .BYTE 1               ; XPos left panel
    XPS1  .BYTE 20              ; XPos right panel
    
    DNU
    DNU0  .BYTE '1              ; Drive Number left
    DNU1  .BYTE '2              ; Drive Number right

    CPOS0 .BYTE 0               ; Cursor Position left
    CPOS1 .BYTE 0               ; Cursor Position right
    CPOSA .BYTE 0               ; Cursor Porition act. Panel

    COFS0 .BYTE 0               ; Cursor Offset left
    COFS1 .BYTE 0               ; Cursor Offset right
    COFSA .BYTE 0               ; Cursor Offset act. Panel

    CABS0 .BYTE 0               ; Cursor absolute Position left
    CABS1 .BYTE 0               ; Cursor absolute Position right
    CABSA .BYTE 0               ; Cursor absolute Position act
    
    NUMD0 .BYTE 0               ; Number of Dir entries left panel
    NUMD1 .BYTE 0               ; Number of Dir entries right panel
    NUMDA .BYTE 0               ; Number of Dir entries act. panel

    ACTFR .BYTE 0               ; act. Panel (0=left, 1=right)
    ACTDM .WORD 0               ; act. Panel dir Memory start
    ACTCF .BYTE 0               ; act. Panel Cursor Flag

    ACTLOCK .BYTE 0             ; lock marker act. entry
    ERRORCD .BYTE 0             ; Errorcode
    XSAVELOCAL .BYTE 0

; >>>>>> VECTORS <<<<<<

VECTAB
    FREMEM      .WORD $6000     ; begin free memory
    DIRMEM0     .WORD $6000     ; begin memory for left panel
    DIRMEM1     .WORD $6500     ; begin memory for right panel
    DIRMEE0     .WORD $64FF     ; end memory for left panel
    DIRMEE1     .WORD $6FFF     ; end memory for right panel
    COPBUF      .WORD $4000     ; length of copy buffer
    ACTVEC      .WORD RTSVEC    ; action table chain vector

    AJMVEC      .WORD RTSVEC        ; active jump vector
    LOCVEC      .WORD LOCKFILE      ; jump vector lock file
    DELVEC      .WORD DELETEFILE    ; jump vector delete file
    COPVEC      .WORD COPYFILE      ; jump vector copy file
    MOVVEC      .WORD MOVEFILE      ; jump vector move file
    RUNVEC      .WORD RUNFILE       ; jimp vector run file

